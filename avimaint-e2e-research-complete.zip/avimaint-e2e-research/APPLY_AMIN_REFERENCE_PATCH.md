# Amin reference patch

This revision supports the published file:

`Cleaned Version of MaintNet's Aviation Maintenance Dataset.xlsx`

## Apply

Extract the patch archive directly into the inner project root—the directory
that already contains `src`, `configs`, `scripts` and `data`. Allow Windows to
replace the existing files.

Rename/copy the Amin workbook to:

`data\aviation\reference\amin_cleaned_dataset.csv`

Then run from Anaconda Prompt:

```bat
scripts\normalization\01_audit_reference.bat
```

Expected structural result:

- 6,169 matched IDs
- no unmatched local/reference records
- `CUTOFF - C`, `CUTOFF - T`, and `ANON` preserved in `reference_edit`
- completed/anonymized rows kept as review-only rather than auto-approved gold

No environment reinstall and no old ByT5 checkpoint are required.

# What to copy from the old normalization project

## Required

| Old item | New location | Purpose |
|---|---|---|
| `Aircraft_Annotation_DataFile.csv` | `data/aviation/raw/` | Immutable 6,169-record source |
| Amin cleaned MaintNet aviation dataset | `data/aviation/reference/amin_cleaned_dataset.csv` | Included expert-expanded reference; audited before training |

## Optional and small

| Old item | New location | Purpose |
|---|---|---|
| Reviewed abbreviation dictionary | `data/dictionaries/abbreviations.yaml` | Rule baseline and safe fallback |
| Reviewed spelling dictionary | `data/dictionaries/` | Rule baseline |
| Old split ID files | `legacy_import/normalization/` | Reproduce the earlier result only |
| Old rules/source scripts | `legacy_import/normalization/` | Comparison and provenance |
| Small metric/prediction CSV or JSON | `legacy_import/normalization/` | Compare old and new experiments |

## Do not copy

- ByT5 model/checkpoint folders
- `optimizer.pt` or scheduler state
- `.venv`, Conda environments or package caches
- Hugging Face caches
- old generated normalized corpora as expert gold
- embeddings or dashboard caches

`normalized_corpus.csv` is useful as a previous rule-output artifact or possible
silver source. It must not automatically become the expert reference. The new
gold experiment is created only from reviewed raw-to-reference pairs.

The published Amin workbook is supported directly. Its `ID` is matched to the
raw `IDENT`; the embedded header row is removed; original problem/action text is
verified; and `CUTOFF - C`, `CUTOFF - T`, and `ANON` edits are preserved for
separate analysis. Do not rename its internal Excel columns.

If the reference file is CSV rather than XLSX, change `reference_path` in
`configs/normalization/data.yaml`; the loader supports both formats.

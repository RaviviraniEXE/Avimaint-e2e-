# Environment Strategy

## Why separate environments?

Normalization, SpERT, retrieval and Streamlit can require incompatible versions of PyTorch, Transformers, Tokenizers or Pydantic. Each environment therefore owns one execution responsibility.

Processes communicate through files:

- JSONL for records, spans and relations
- Parquet for large tables and representations
- JSON for manifests, configurations and metrics
- CSV for thesis tables
- model directories referenced by manifest path, not imported by the dashboard

## Installation rules

1. Use Python 3.11 unless an imported legacy model demonstrably requires another version.
2. Never install all requirements into one environment.
3. Never run pip install from the base Conda environment.
4. Change pins only inside the affected environment.
5. After changing a requirement, rerun the verification script and record the change.
6. Use python -m pip so pip belongs to the active environment.
7. Do not store .venv or Conda environment directories inside the repository.

## GPU note

The provided requirements use the normal PyPI PyTorch package for portability. For a CUDA-specific build, install the PyTorch build recommended for the local driver inside only the relevant environment:

- avimaint-normalization
- avimaint-ie-neural
- avimaint-spert
- avimaint-retrieval, only if dense embedding inference uses the GPU

Do not change the dashboard environment to solve a GPU issue.

## Official SpERT

SpERT is isolated because the archived official source has a different
compatibility envelope from the dashboard and newer transformer modules. Run
`scripts/setup/clone_official_spert.bat`; it clones `lavis-nlp/spert` without
source changes and records the resolved commit. Change pins only in
`envs/spert/requirements.txt` and record any change in the experiment manifest.

## Reproducible freeze

After an environment is working, freeze it:

~~~powershell
conda run -n avimaint-spert python -m pip freeze > environment-freezes\avimaint-spert.txt
~~~

Create the environment-freezes directory first. Freeze files document the successful machine state; the curated requirements files remain the human-maintained installation specification.

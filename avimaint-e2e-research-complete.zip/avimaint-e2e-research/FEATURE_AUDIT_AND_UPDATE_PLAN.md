# Feature audit and retained implementation

The rebuild preserves the useful capabilities of the previous normalization,
information-extraction, retrieval and dashboard projects while removing
duplicate runtimes and unsupported claims.

| Area | Included implementation | Update/decision |
|---|---|---|
| Normalization | raw, rules, ByT5, rules-then-ByT5; protected tokens; audits; cluster-safe splits | Amin expert expansion retained as sensitivity evidence; lexical targets separated from completions |
| Annotation | pilot 300, round1 500, rare rounds 300+300+200 | Immutable source plus audited training copy; 1,600 unique IDs |
| Schema | full 9 entities/11 relations | `REFERENCE` retained; derived core 8/10 ablation added, no reannotation |
| IE baselines | CRF/LogReg, BiLSTM/neural RE, transformer NER/RE | Identical frozen split and multi-seed reporting contract |
| Joint IE | SpERT | Official `lavis-nlp/spert` cloned and commit-pinned; separate environment; no rewritten clone |
| External validity | MaintIE native benchmark and span ablation | Separate 1,076-record dataset; never mixed into aviation cases |
| Retrieval | BM25, TF-IDF word/character, structure and hybrid | Problem-only query contract; cluster exclusion; raw/System-D comparison |
| Uncertainty | confidence features, calibration, risk-coverage | Calibrate on DEV, evaluate once on TEST; no unvalidated “well-calibrated” wording |
| Dashboard | overview, diagnosis, insights, KG, planning, evaluation and guide | One final dashboard; evidence stays visible; low confidence produces warnings rather than a blank result |
| Safety | provenance, alternatives, negative evidence, current-approved-data notice | No LLM procedure generation and no claim of maintenance authority |

The project intentionally excludes environments, caches, downloaded model
weights, old checkpoints and duplicate dashboard copies. These are recreated by
the numbered setup and training launchers.


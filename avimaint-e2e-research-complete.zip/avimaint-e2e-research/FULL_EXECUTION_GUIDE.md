# Complete execution guide (Windows + Anaconda)

This project retrains every model from source. No old checkpoint is required.
Run commands from the single folder that contains `README.md`, `scripts`,
`configs`, `src`, and `legacy_import`.

```bat
cd /d D:\avimaint-e2e-research
python scripts\verify\project_readiness.py --compile
```

If Windows Explorer shows two folders with the same name, enter the inner one.
The readiness command must finish with no `[FAIL]` lines before training.

## 1. Install eight isolated environments

Install Git, Anaconda/Miniconda and (for GPU training) an NVIDIA driver. Then:

```bat
powershell -ExecutionPolicy Bypass -File scripts\setup\setup_all.ps1
scripts\setup\setup_gpu_models.bat
scripts\setup\clone_official_spert.bat
```

`setup_all.ps1` creates independent environments for core utilities,
normalization, classical IE, neural IE, official SpERT, retrieval, dashboard,
and development. Every environment has its own files under `envs\`. The clone
launcher obtains the official `lavis-nlp/spert` repository and records its exact
commit in `external\spert\UPSTREAM_PROVENANCE.json`; the project does not contain
a rewritten or vendored SpERT implementation.

Verify installed packages:

```bat
powershell -ExecutionPolicy Bypass -File scripts\verify\verify_all.ps1
```

## 2. RQ1 — normalization from scratch

The raw and Amin expert-expanded files are included. Amin's expert knowledge is
not rejected: lexical/abbreviation pairs form the primary target population,
while completions of truncated or anonymized source text form a separately
reported sensitivity population. This prevents WER from treating plausible new
information as if it were recoverable from the source.

```bat
scripts\normalization\01_audit_reference.bat
scripts\normalization\02_prepare_approved_pairs.bat
scripts\normalization\03_create_cluster_safe_split.bat
scripts\normalization\04_train_byt5_gold.bat
scripts\normalization\05_run_validation_comparison.bat
scripts\normalization\05b_run_validation_ablations.bat
```

The primary comparison is exactly raw, rules, ByT5, and rules-then-ByT5. Select
hyperparameters and the final system only from validation results. Then run the
locked test exactly once:

```bat
scripts\normalization\06_run_final_test_once.bat CONFIRM_TEST
scripts\normalization\09_predict_full_corpus.bat
```

After selecting the model, run the separate expert-expansion sensitivity study:

```bat
scripts\normalization\05c_run_expert_sensitivity.bat
```

Its 1,045 completion/truncation/anonymization pairs never affect model selection.

Optional silver pretraining is an ablation, never silently mixed into the main
four-system result:

```bat
scripts\normalization\07_make_silver_data.bat
scripts\normalization\08_train_silver_then_gold.bat
```

Report WER, CER, exact match, change F1, protected-token accuracy, unsupported
insertion rate, and confidence intervals. Do not claim normalization improves
the end system unless the downstream IE or retrieval experiment confirms it.

## 3. RQ2 — annotation audit and schema study

The package contains 1,600 annotated records: 800 random records and 800
rare-enriched training records. The authoritative source batches are immutable.
The installer audits them and writes a corrected training copy with provenance.

```bat
scripts\ie\01_import_annotations.bat
scripts\ie\02_freeze_split.bat
```

The final split is 1,275 train / 100 development / 225 held-out test. Rare-
enriched records occur only in training, and exact duplicate groups do not cross
partitions.

The full frozen schema has 9 entities and 11 relations, including `REFERENCE`
and `ACTION_FOLLOWS_REFERENCE`. They are not deleted. A derived 8/10 core view
removes only that sparse extension so the thesis can compare learnability and
planning-field coverage without reannotation:

```bat
scripts\ie\02a_audit_and_build_schema_views.bat
scripts\ie\03b_train_core_schema_classical.bat
scripts\ie\04b_train_core_schema_neural.bat
scripts\ie\05b_export_spert_core.bat
scripts\ie\06b_train_and_test_spert_core.bat
```

Compare label support, per-class F1, strict micro/macro F1, orphan/signature
errors, and planning-field coverage. The unbiased test has only two reference
relations; therefore report support and uncertainty and do not make a strong
standalone reference-class claim.

## 4. RQ3 — aviation information extraction

All systems use the identical frozen split. Classical and neural tiers are kept
because a strong thesis needs credible baselines, not only the largest model.

```bat
scripts\ie\03_train_classical.bat
scripts\ie\04_train_neural.bat
scripts\ie\05_export_spert.bat
scripts\ie\06_train_and_test_spert.bat
scripts\ie\07_import_spert_and_report.bat
```

Models: CRF + logistic-regression RE, BiLSTM-CRF + neural RE, transformer NER/RE,
and official joint SpERT. Repeat stochastic neural runs with seeds 42, 123, and
2026 and report mean, standard deviation, per-class results, bootstrap intervals,
and paired significance. Never tune against the 225-record test set.

Run normalization-to-IE projection only after full/core annotation audit:

```bat
scripts\normalization\10_compare_downstream_ie.bat
```

The script stops below 97% span-projection coverage and saves row-level QC.

## 5. RQ4 — MaintIE external benchmark

MaintIE is a separate 1,076-record external benchmark with its native five-
entity/six-relation schema and 860/108/108 split. It tests whether model-family
conclusions generalize; it never becomes aviation dashboard data.

```bat
scripts\maintie\01_prepare.bat
scripts\maintie\02_train_baselines.bat
scripts\maintie\03_span_ablation.bat
scripts\maintie\04_export_spert.bat
scripts\maintie\05_train_and_test_spert.bat
```

Report native-schema scores first. Any shared/coarse mapping is an additional
audited comparison, not a replacement for native evaluation.

## 6. Full-corpus extraction and cases

After choosing the aviation IE model from development data and reporting the
frozen test once:

```bat
scripts\ie\08_prepare_full_corpus.bat
scripts\ie\08b_predict_full_corpus_spert.bat
scripts\ie\09_build_knowledge_graph.bat outputs\kg\predictions_full.json
scripts\dashboard\export_dataset.bat rules_then_byt5
```

Full-corpus inference is for case construction, insights, and the knowledge
graph. It is not another held-out test.

## 7. RQ5 — leakage-safe historical-case retrieval

Queries contain only problem-side text and structure. Recorded actions are read
only after ranking to calculate recorded action-family agreement.

Primary leave-one-cluster-out comparison over the available query population:

```bat
scripts\dashboard\run_rq5_retrieval.bat --protocol loo
```

Additional frozen generalization check (train cases are candidates; held-out
test cases are queries):

```bat
scripts\dashboard\run_rq5_retrieval.bat --protocol frozen
```

Both commands compare raw and rules-then-ByT5 across BM25, TF-IDF, structural,
and hybrid representations. Report Top-1/Top-3 recorded action-family agreement,
MRR, nDCG@3, macro recall, per-family recall, and diversity. These metrics are
historical agreement, not proof of technical correctness. A claim about useful
or applicable cases requires qualified-expert relevance assessment.

## 8. RQ6 — uncertainty and auditable planning support

Calibration is fitted on the frozen development partition and evaluated once on
the frozen test partition:

```bat
scripts\dashboard\run_rq6_uncertainty.bat --system rules_then_byt5 --representation hybrid
scripts\dashboard\run_robustness.bat --system rules_then_byt5 --representation hybrid
```

Report ECE, Brier score, risk-coverage, evidence coverage, and provenance
completeness. Truncation, spelling noise, and missing-structure stress tests are
automatic. Multi-problem records are exported for qualitative review because
joining two problems does not yield one valid gold action-family label.

## 9. Launch the final dashboard

```bat
scripts\dashboard\run_evaluation.bat
scripts\dashboard\run_dashboard.bat
```

The only final dashboard is `legacy_import\maintenance-ie\avimaint_dss`. It
contains Overview, Diagnose, Dataset Insights, Knowledge Graph, Planning,
Evaluation, and Guide pages. Nearest traceable cases remain visible even at low
confidence; confidence changes badges, warnings, and context requests instead
of hiding all evidence. The interface preserves IDs, raw text, alternatives,
negative/mixed outcomes, and uncertainty. It does not generate procedures or
claim maintenance authority.

## 10. Final evidence checklist

For every thesis table retain the configuration, dataset/split/schema version,
seed, upstream model/repository commit, metrics, predictions, error analysis,
and environment lock. Keep these populations separate:

| Study | Evaluation population |
|---|---:|
| Normalization primary | 3,457 train / 926 validation / 741 test from 5,124 approved lexical/abbreviation pairs |
| Normalization sensitivity | 1,045 separately labelled expert-completion/truncation/anonymization pairs |
| Aviation IE | 225 held-out random records |
| MaintIE | 108 held-out records |
| Retrieval LOO | eligible non-`Other` cluster-safe queries from 6,169 cases |
| Retrieval frozen | held-out query cases from the 4,555/539/1,075 case split |

Run final validation after any code change:

```bat
conda run -n avimaint-dev python -m pytest -q
python scripts\verify\project_readiness.py --compile
```

Never combine scores from these different populations into one denominator.

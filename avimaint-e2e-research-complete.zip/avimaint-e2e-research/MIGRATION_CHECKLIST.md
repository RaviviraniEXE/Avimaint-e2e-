# Migration Checklist

## Stage 1: Preserve

- Keep the existing project untouched.
- Create a commit or archive of the existing baseline.
- Record the dataset filenames and SHA-256 hashes.
- Record current model names and metric files.
- Copy previous source code into legacy_import/.
- Do not copy virtual environments, caches or large checkpoints into Git.

## Stage 2: Freeze the data protocol

- Assign stable dataset_id and record_id values.
- Detect exact and near duplicates.
- Create cluster_id values.
- Freeze train, development and test ID files.
- Save the split-generation configuration and seed.
- Confirm that related duplicate groups cannot cross splits.

## Stage 3: Reproduce

- Run the old normalization pipeline.
- Run the old IE pipeline.
- Run the old retrieval pipeline.
- Save reproduced metrics separately from originally reported metrics.
- Explain any difference before changing methods.

The legacy normalization reproduction is optional when the old checkpoint is too
large to move. In that case, preserve its published predictions, metrics and
configuration as provenance, then train all new checkpoints from the original
pretrained model. Do not silently label the new run as an exact reproduction.

## Stage 4: Port

- Port adapters and validation first.
- Port normalization without changing behavior.
- Port each IE tier separately.
- Port retrieval baselines before hybrid retrieval.
- Port the dashboard last.

## Stage 5: Extend

- RQ1 downstream normalization ablation
- RQ2 schema/model and MaintIE benchmark
- RQ3 structured retrieval ablation
- RQ4 truncation and missing-context stress tests
- RQ5 confidence calibration and abstention

## Stage 6: Freeze thesis results

- Lock test predictions.
- Generate final tables and figures from saved artifacts.
- Record the final commit identifier.
- Update the complete thesis results only after the experimental protocol is frozen.

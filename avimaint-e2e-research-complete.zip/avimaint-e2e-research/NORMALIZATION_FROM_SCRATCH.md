# Normalization From Scratch

This project does not require any checkpoint from the old normalization folder.
The old project should remain separate and unchanged.

## Copy only these inputs

1. `Aircraft_Annotation_DataFile.csv` to `data/aviation/raw/`.
2. The cleaned or expanded normalization reference to `data/aviation/reference/`.
3. Optional reviewed abbreviation and spelling dictionaries to `data/dictionaries/`.
4. Optional old source scripts to `legacy_import/normalization/` for comparison only.

Do not copy checkpoints, `optimizer.pt`, caches, virtual environments, generated
predictions or old output directories.

The default configuration targets the included CSV export of Amin's published
cleaned release at `data/aviation/reference/amin_cleaned_dataset.csv`. The audit
matches Amin `ID` to raw `IDENT` and verifies both original fields.
Completed cutoff (`CUTOFF - C`) and anonymized (`ANON`) rows remain review-only
by default rather than becoming automatic lexical-normalization gold.

## Windows sequence

From Windows Anaconda Prompt (`cmd.exe`), use:

```bat
scripts\setup\setup_normalization_gpu.bat
```

The numbered `.bat` workflow is documented in `START_HERE_WINDOWS_CMD.md`.

From PowerShell, use:

```powershell
.\scripts\setup\setup_normalization_gpu.ps1
conda run -n avimaint-normalization python -m avimaint.normalization audit --config configs/normalization/data.yaml
```

For a CPU-only installation, use `.\scripts\setup\setup_one.ps1 normalization`.

The included `normalization_manual_review.csv` is already completed for all
6,169 pairs. Re-running step 1 refreshes the deterministic pair audit but does
not overwrite that completed review. The primary population contains lexical
corrections/defensible expansions; completion, truncation and anonymization rows
remain available as a separate expert-extended sensitivity population.

```powershell
conda run -n avimaint-normalization python -m avimaint.normalization prepare --config configs/normalization/data.yaml
conda run -n avimaint-normalization python -m avimaint.normalization split --config configs/normalization/split.yaml
conda run -n avimaint-normalization python -m avimaint.normalization train --config configs/normalization/byt5_gold.yaml
conda run -n avimaint-normalization python -m avimaint.normalization predict --config configs/normalization/byt5_gold.yaml --split test
conda run -n avimaint-normalization python -m avimaint.normalization evaluate --config configs/normalization/byt5_gold.yaml --split test
```

Run the silver-to-gold condition only after the gold-only experiment is frozen:

```powershell
conda run -n avimaint-normalization python -m avimaint.normalization make-silver --config configs/normalization/data.yaml
conda run -n avimaint-normalization python -m avimaint.normalization train --config configs/normalization/byt5_silver_then_gold.yaml
```

## Research gates

- Duplicate clusters, not rows, define the split.
- Development data selects the model; test data is evaluated once.
- Run the selected configuration with seeds 42, 123 and 2026.
- The primary comparison is exactly raw, rules, ByT5 and rules-then-ByT5. Optional
  MFR, selective-ByT5 and silver-to-gold experiments are labelled as ablations.
- Raw text is immutable and remains the authoritative dashboard evidence.
- A lower WER is insufficient if protected identifiers or meaning are changed.
- Fixed-width truncation is not permission to invent missing maintenance facts.
- Downstream IE and retrieval ablations determine whether normalization is useful.

# Project completion status

## Included and verified

- 6,169-record raw aviation corpus and paired Amin expert-expanded reference
- completed normalization pair audit and manual-review artifacts
- 1,600 authoritative and audited aviation IE annotations
- frozen 1,275/100/225 aviation IE split with duplicate-group isolation
- full 9/11 and derived core 8/10 schema views
- four normalization systems and optional ablations
- CRF, BiLSTM, transformer and official-SpERT integration
- separate MaintIE 860/108/108 external benchmark
- full-corpus extraction, KG/case construction launchers
- leakage-safe RQ5 retrieval and DEV-calibrated RQ6 uncertainty modules
- one consolidated evidence-friendly dashboard
- isolated Conda environments, Windows launchers, tests and readiness audit

## Intentionally not precomputed

GPU checkpoints and new final metrics are not fabricated or bundled. Run the
numbered workflow in `FULL_EXECUTION_GUIDE.md`. Test results become thesis claims
only after the corresponding fresh training/evaluation command completes.


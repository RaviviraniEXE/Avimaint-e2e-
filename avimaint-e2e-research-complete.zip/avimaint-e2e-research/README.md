# AviMaint End-to-End Research Pipeline

Start with `START_HERE.bat`, then follow `FULL_EXECUTION_GUIDE.md`. The complete
repository audit and every retained/updated feature are documented in
`FEATURE_AUDIT_AND_UPDATE_PLAN.md`; current execution status is in
`PROJECT_COMPLETION_STATUS.md`.

This scaffold is designed for the thesis:

**Development and Evaluation of an NLP-Based Concept for Structured Information Extraction and Planning Support in Maintenance Work Orders**

It separates model environments, preserves dataset and schema provenance, supports the aviation end-to-end pipeline, and treats MaintIE as an external information-extraction benchmark.

## Non-negotiable research rules

1. Keep the original aviation records immutable.
2. Preserve source record IDs through every stage.
3. Freeze duplicate-aware train, development, and test splits before training.
4. Never tune on the test set.
5. Never call the manually expanded aviation release unquestioned ground truth. Treat it as a reference representation.
6. Never mix MaintIE records into the aviation recommender unless a separate compatibility study establishes that they are valid problem-action cases.
7. Every output must record dataset version, split version, schema version, configuration, seed, model reference, and code revision.
8. The dashboard demonstrates results. Saved evaluation artifacts are the scientific evidence.

## Environment isolation

The project uses eight independent Conda environments:

| Environment | Purpose |
|---|---|
| avimaint-core | Data adapters, validation, schemas, splits, reporting |
| avimaint-normalization | Rules, ByT5, hybrid normalization |
| avimaint-ie-classical | CRF and logistic-regression baselines |
| avimaint-ie-neural | BiLSTM and transformer extraction |
| avimaint-spert | SpERT kept separate from other transformer packages |
| avimaint-retrieval | BM25, TF-IDF, embeddings, hybrid retrieval |
| avimaint-dashboard | Lightweight Streamlit interface using saved artifacts |
| avimaint-dev | Tests, linting and notebooks |

Each environment has its own environment.yml and requirements.txt under envs/.
They exchange JSONL, Parquet, CSV and JSON artifacts under outputs/. They do not share an in-process Python runtime.

## Quick start on Windows

Open Anaconda Prompt or PowerShell with Conda available:

~~~powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\setup\setup_all.ps1
~~~

To create only one environment:

~~~powershell
.\scripts\setup\setup_one.ps1 core
.\scripts\setup\setup_one.ps1 normalization
.\scripts\setup\setup_one.ps1 ie-classical
.\scripts\setup\setup_one.ps1 ie-neural
.\scripts\setup\setup_one.ps1 spert
.\scripts\setup\setup_one.ps1 retrieval
.\scripts\setup\setup_one.ps1 dashboard
.\scripts\setup\setup_one.ps1 dev
~~~

Run the installation check:

~~~powershell
.\scripts\verify\verify_all.ps1
~~~

## Quick start on Linux

~~~bash
bash scripts/setup/setup_all.sh
bash scripts/verify/verify_all.sh
~~~

## First commands

Validate the aviation configuration:

~~~powershell
conda run -n avimaint-core python -m avimaint.pipelines.aviation_e2e --config configs/experiments/rq1_normalization.yaml --dry-run
~~~

Validate the MaintIE benchmark configuration:

~~~powershell
conda run -n avimaint-core python -m avimaint.pipelines.maintie_benchmark --config configs/experiments/rq4_maintie.yaml --dry-run
~~~

Start the single final evidence-friendly dashboard:

~~~powershell
scripts\dashboard\run_dashboard.bat
~~~

## End-to-end workflows

### Aviation

raw records -> expert-reference audit -> duplicate clusters -> four normalization
systems -> full/core schema study -> frozen IE split -> four IE tiers ->
full-corpus cases/KG -> leakage-safe retrieval -> calibrated evidence and
alternatives -> planning-support interface

### MaintIE

official release -> MaintIE adapter -> native/shared schema -> IE evaluation -> benchmark reports

MaintIE is not routed into aviation planning support by default.

## Copying previous work

Do not paste old virtual environments, caches, checkpoints or output folders into this project.

Copy only:

- Source scripts that produced documented results
- Frozen annotation files
- Dataset manifests or pointers
- Exact split files
- Model configuration files
- Small metric and prediction artifacts
- Documentation needed to reproduce the old baseline

First place copied code under legacy_import/ without modifying it. Reproduce the baseline. Then port one component at a time into src/avimaint/.

See MIGRATION_CHECKLIST.md and ENVIRONMENTS.md before moving code.

## Normalization retraining

The scaffold includes a complete independent normalization workflow. It trains
new ByT5 checkpoints from `google/byt5-small`; no old checkpoint is required.
Follow `NORMALIZATION_FROM_SCRATCH.md`. The first mandatory stage audits the
expanded reference so that unsupported reconstruction of fixed-width text is
not treated as ordinary lexical normalization.

# Start here: Windows Anaconda Prompt

The `.ps1` files are PowerShell scripts. Anaconda Prompt normally uses
`cmd.exe`, so use the included `.bat` launchers.

## 1. Confirm the extracted location

```bat
D:
cd \avimaint-e2e-research
dir
```

You should see `README.md`, `src`, `scripts`, `configs` and `envs`.

If `dir` shows another folder named `avimaint-e2e-research`, enter it once:

```bat
cd avimaint-e2e-research
dir
```

## 2. Create the normalization GPU environment

```bat
scripts\setup\setup_normalization_gpu.bat
```

## 3. Copy data and check the configuration

- Raw source: `data\aviation\raw\Aircraft_Annotation_DataFile.csv`
- Cleaned reference: `data\aviation\reference\amin_cleaned_dataset.csv`

The included `configs\normalization\data.yaml` already matches these files.

## 4. Run the numbered workflow

```bat
scripts\normalization\01_audit_reference.bat
```

Review `data\aviation\interim\normalization_manual_review.csv`. Then run:

```bat
scripts\normalization\02_prepare_approved_pairs.bat
scripts\normalization\03_create_cluster_safe_split.bat
scripts\normalization\04_train_byt5_gold.bat
scripts\normalization\05_run_validation_comparison.bat
```

Do not run the final-test launcher until the final configuration has been
selected from validation results.

For the complete normalization, IE, MaintIE, retrieval, uncertainty and
dashboard workflow, continue with `FULL_EXECUTION_GUIDE.md`.

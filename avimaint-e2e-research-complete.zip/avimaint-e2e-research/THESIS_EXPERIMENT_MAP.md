# Thesis research questions and evidence map

| RQ | Simple research question | Main evidence |
|---|---|---|
| RQ1 | How much can controlled normalization help noisy work orders without changing technical meaning? | Four-system normalization comparison plus downstream IE/retrieval ablations |
| RQ2 | Which entity/relation schema is useful for planning and still learnable from the available annotations? | Frozen full 9/11 schema versus derived core 8/10 view; support, F1, validity and coverage |
| RQ3 | Which model extracts aviation maintenance entities and relations most accurately and robustly? | CRF/LogReg, BiLSTM, transformer and official SpERT on the same 1,275/100/225 split |
| RQ4 | Do the extraction conclusions remain credible on an external maintenance benchmark? | MaintIE native 5/6 schema on its separate 860/108/108 split |
| RQ5 | Which problem-only representation retrieves the strongest historical cases without action leakage? | Raw/System-D × BM25/TF-IDF/structure/hybrid; LOO primary and frozen generalization check |
| RQ6 | How should evidence, alternatives and uncertainty be shown without pretending to make an approved decision? | DEV-calibrated confidence, held-out ECE/Brier/risk-coverage, provenance audit and dashboard policy |

Cross-cutting robustness tests cover truncation, spelling noise and missing
structure. Multi-problem inputs are reviewed qualitatively unless a valid
multi-label gold standard is created.

Minimum artifact set per experiment: configuration, run manifest, predictions,
metrics, per-class/error analysis, seed, environment, dataset/split/schema IDs,
and code/upstream revision. The dashboard is a demonstrator; saved held-out
evaluation artifacts are the scientific evidence.


# Validation report

Validated on 25 August 2026 before packaging.

## Passed checks

- 13 unit/contract tests passed.
- Python compilation passed for the new package, launchers, aviation IE,
  MaintIE, and the final dashboard.
- YAML parsing passed for every configuration file.
- Key new and modified research modules pass Ruff checks.
- Windows launchers use paths relative to the project root; no user-specific
  drive path is required.
- Linux setup scripts pass `bash -n` syntax validation.
- Normalization reference audit reproduced 6,169 paired rows without overwriting
  the completed human decisions.
- Primary normalization preparation produced 5,124 approved pairs and a
  duplicate-cluster-safe 3,457/926/741 split.
- A separate 1,045-pair expert-expansion sensitivity set was reproduced.
- Aviation annotation installation reproduced 1,600 structurally valid unique
  records, removed one exact duplicate relation, harmonized one strict-superset
  duplicate, and left zero unresolved duplicate groups.
- The frozen aviation IE split reproduced 1,275/100/225 with zero exact-group
  overlap and no rare-enriched records in development or test.
- Full and core official-SpERT exports reproduced 1,275/100/225 files and valid
  9/11 versus 8/10 type definitions.
- MaintIE contains 1,076 records with its independent 860/108/108 split.
- RQ5 retrieval and cross-cutting robustness launchers passed limited smoke
  executions on both corpus loading and ranking paths. Smoke outputs were
  excluded from the deliverable and are not thesis results.

## Deliberately not claimed

GPU training, final model checkpoints, and final held-out metrics are not
precomputed in this package. They require the user's hardware and are produced
only by the numbered commands in `FULL_EXECUTION_GUIDE.md`. Existing historical
metrics must not be presented as results of the rebuilt pipeline.


# Experiments

Experiment folders contain analysis notes and optional orchestration scripts. Canonical machine-readable configurations live in configs/experiments/.

Never manually edit a test prediction file after evaluation.


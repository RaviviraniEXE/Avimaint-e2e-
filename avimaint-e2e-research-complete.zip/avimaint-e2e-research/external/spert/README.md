# Official SpERT checkout location

Do not place a hand-written or copied SpERT implementation here. Run:

```text
scripts\setup\clone_official_spert.bat
```

The setup clones the official archived upstream repository
`https://github.com/lavis-nlp/spert.git`, keeps its source unmodified, and writes
`UPSTREAM_PROVENANCE.json` with the exact commit used. The upstream repository
was archived on 2 April 2025, so "latest" means the HEAD of its read-only
`master` branch. Every thesis run must report the recorded commit.

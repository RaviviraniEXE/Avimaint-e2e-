@echo off
title AviMaint-DSS launcher
cd /d "%~dp0"

REM --- auto-detect project root (parent folder = maintenance-ie) ---
for %%I in ("%~dp0..") do set "PROJECT_ROOT=%%~fI"

echo ============================================================
echo   AviMaint-DSS - one-click start
echo   Project root: %PROJECT_ROOT%
echo ============================================================
echo.
echo [1/3] Installing dependencies (first run only)...
python -m pip install -q -r requirements.txt
python -m pip install -q torch transformers safetensors
echo.

echo [2/3] Starting SpERT model service in a separate window...
start "AviMaint SpERT service" cmd /k python services\spert_query_service.py --project-root "%PROJECT_ROOT%"
echo      Waiting for the model to load (large checkpoint, ~30-60s)...
timeout /t 25 /nobreak >nul
echo.

echo [3/3] Starting the dashboard...
echo      The sidebar shows SpERT: ON once the model is ready.
python -m streamlit run app.py

pause


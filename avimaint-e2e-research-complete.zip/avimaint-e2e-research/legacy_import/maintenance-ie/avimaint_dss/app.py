"""AviMaint-DSS — explainable maintenance planning support.

Four pages: Overview · Diagnose · Insights · Planning.
Deterministic core; SpERT predictions enhance structure when the service is on.
Run:  streamlit run app.py
"""
from __future__ import annotations

import os
from pathlib import Path

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components
from streamlit_option_menu import option_menu
import yaml

from core.corpus import load_corpus
from core.extraction import SpERTClient
from core.retrieval import Retriever
from core.recommend import Recommender, badge_label
from core.reranker import CrossEncoderReranker
from core import insights as I
from core import watchlist as W
from core import kg as KG
from core import evaluate as EV
import plotly.graph_objects as go
from ui import theme as T
from ui import charts as C

ROOT = Path(__file__).resolve().parent


# --------------------------------------------------------------------------- #
# Loaders (cached)
# --------------------------------------------------------------------------- #
@st.cache_data(show_spinner=False)
def get_config() -> dict:
    with open(ROOT / "config.yaml", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


@st.cache_resource(show_spinner="Loading corpus and building structure…")
def get_corpus(cfg_key: str):
    cfg = get_config()
    csv = ROOT / cfg["data"]["csv_path"]
    pred = cfg["data"].get("predictions_path") or None
    corpus = load_corpus(csv, mode=cfg["extraction"]["mode"],
                         spert_url=cfg["extraction"]["spert_url"],
                         predictions_path=(ROOT / pred) if pred else None,
                         normalize=cfg["extraction"].get("normalize", True))
    return corpus


@st.cache_resource(show_spinner="Building retrieval index…")
def get_engine(cfg_key: str):
    cfg = get_config()
    corpus = get_corpus(cfg_key)
    dense = cfg["retrieval"].get("dense_model") or None
    retr = Retriever(corpus.df, dense_model=dense)
    client = None
    if cfg["extraction"]["mode"] == "spert":
        c = SpERTClient(cfg["extraction"]["spert_url"])
        client = c if c.health() else None
    rr_model = cfg["retrieval"].get("reranker_model") or None
    reranker = CrossEncoderReranker(rr_model, cfg["retrieval"].get("reranker_blend", 0.7)) if rr_model else None
    rcfg = cfg.get("recommender", {})
    rec = Recommender(
        corpus.df, retr, spert_client=client, normalizer=corpus.normalizer,
        reranker=reranker, strong_score=rcfg.get("strong_score", 0.42),
        moderate_score=rcfg.get("moderate_score", 0.22),
        widening_score=rcfg.get("widening_score", 0.06),
    )
    return retr, rec


# ---- cached heavy computes (keyed by config signature) -------------------- #
@st.cache_data(show_spinner=False)
def c_kpis(key, recurring_min):
    return I.kpis(get_corpus(key).df, recurring_min)

@st.cache_data(show_spinner=False)
def c_recurring(key, min_support, n):
    return I.recurring_watchlist(get_corpus(key).df, min_support, n)

@st.cache_data(show_spinner=False)
def c_top_recurring(key, n):
    return I.top_recurring_problems(get_corpus(key).df, n)

@st.cache_data(show_spinner=False)
def c_component_freq(key, n):
    return I.component_frequency(get_corpus(key).df, n)

@st.cache_data(show_spinner=False)
def c_fault_freq(key, n):
    return I.fault_frequency(get_corpus(key).df, n)

@st.cache_data(show_spinner=False)
def c_action_freq(key):
    return I.action_frequency(get_corpus(key).df)

@st.cache_data(show_spinner=False)
def c_matrix(key, tc, tf):
    return I.component_fault_matrix(get_corpus(key).df, tc, tf)

@st.cache_data(show_spinner=False)
def c_outcome(key):
    return I.outcome_mix(get_corpus(key).df)

@st.cache_data(show_spinner=False)
def c_p2a(key, comp):
    return I.problem_to_action(get_corpus(key).df, "component", comp)

@st.cache_data(show_spinner=False)
def c_kg_html(key, tc, tf, min_edge, focus):
    return KG.corpus_graph(get_corpus(key).df, tc, tf, min_edge, focus or None)

@st.cache_data(show_spinner=False)
def c_component_list(key, n):
    return I.component_frequency(get_corpus(key).df, n)["component"].tolist()


def cfg_signature(cfg: dict) -> str:
    e = cfg["extraction"]
    return (f'{e["mode"]}|{e.get("normalize", True)}|{cfg["data"].get("csv_path")}'
            f'|{cfg["data"].get("predictions_path")}|{cfg["retrieval"].get("dense_model")}'
            f'|{cfg["retrieval"].get("reranker_model")}')


# --------------------------------------------------------------------------- #
# Pages
# --------------------------------------------------------------------------- #
def page_overview(key: str, cfg: dict):
    st.markdown("### Overview")
    st.markdown('<div class="muted">The shape of your maintenance corpus at a glance. '
                'All figures are observed work-order counts — never failure rates.</div>',
                unsafe_allow_html=True)
    k = c_kpis(key, cfg["insights"]["recurring_min"])
    T.kpi_row([
        ("Work orders", f'{k["work_orders"]:,}', ""),
        ("Unique problems", f'{k["unique_problems"]:,}', ""),
        ("Problem clusters", f'{k["problem_clusters"]:,}', ""),
        ("Components tracked", f'{k["components_tracked"]:,}', ""),
        ("Recurring faults", f'{k["recurring_faults"]:,}', f'≥{cfg["insights"]["recurring_min"]} work orders'),
        ("Recorded outcomes", f'{k["recorded_outcomes_pct"]:.0f}%', "rest unknown"),
    ])
    c1, c2 = st.columns([1.15, 1])
    with c1:
        T.section("Recurring problems (chronic faults)",
                  "The problems your fleet keeps seeing — where a standing plan pays off.")
        rec = c_top_recurring(key, 12)
        st.dataframe(rec.rename(columns={
            "problem": "Problem", "work_orders": "Work orders", "component": "Component",
            "fault": "Fault", "top_action": "Usual action"}).drop(columns=["cluster_id"]),
            hide_index=True, use_container_width=True, height=460)
    with c2:
        T.section("Most-involved components", "What shows up most in problems.")
        st.plotly_chart(C.hbar(c_component_freq(key, 10), "component", "work_orders"),
                        use_container_width=True, config={"displayModeBar": False})
        T.section("What you do most", "Recorded action families.")
        st.plotly_chart(C.action_bars(c_action_freq(key), "action_family", "work_orders", 260),
                        use_container_width=True, config={"displayModeBar": False})


def _render_cases(cases, key_prefix=""):
    for cse in cases:
        st.markdown(
            f'<div class="card"><span class="caseid">{cse.ident}</span> '
            f'<span class="pill">{cse.action_family}</span> '
            f'<span class="pill">outcome: {cse.outcome}</span><br>'
            f'<div style="margin-top:6px"><b>Problem:</b> {cse.problem}</div>'
            f'<div><b>Recorded action:</b> {cse.action}</div></div>',
            unsafe_allow_html=True)


def _render_strategy(s):
    star = '<span class="star">★ primary</span>' if s.is_primary else ""
    weak = ('<span class="pill" style="color:#eda100">single-case · weak evidence</span>'
            if s.tier == "single_case" else "")
    out = (f'<span class="pill" style="color:#0ca30c">✔ {s.outcome_positive} positive</span>'
           if s.outcome_positive else "")
    neg = (f'<span class="pill" style="color:#e66767">✕ {s.outcome_negative} neg</span>'
           if s.outcome_negative else "")
    ex = ""
    if s.examples:
        e = s.examples[0]
        ex = (f'<div class="muted" style="margin-top:6px">e.g. '
              f'<span class="caseid">{e["ident"]}</span> {e["action"]}</div>')
    cls = "primary" if s.is_primary else ("weak" if s.tier == "single_case" else "")
    st.markdown(
        f'<div class="strat {cls}">'
        f'<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">'
        f'<span class="pill" style="font-weight:700">{s.family}</span>{star}{weak}'
        f'<span class="pill">{s.case_count} work orders · {s.support_clusters} groups</span>'
        f'{out}{neg}</div>'
        f'<div class="reco2">➜ {s.sentence}</div>'
        f'<div class="muted">{s.meaning}</div>{ex}</div>',
        unsafe_allow_html=True)


def _render_extraction(R):
    """Show the SpERT (or lexicon) entities + relations, and a mini knowledge graph."""
    if not R.entities and not R.relations:
        return
    st.markdown("#### What the model extracted")
    chips = "".join(
        f'<span class="ent" style="background:{KG.TYPE_COLOR.get(e.get("type"),"#5a5a55")}22;'
        f'border:1px solid {KG.TYPE_COLOR.get(e.get("type"),"#5a5a55")}">'
        f'<b>{e.get("text","")}</b> <span class="etype">{e.get("type")}</span></span>'
        for e in R.entities)
    st.markdown(f'<div class="entrow">{chips}</div>', unsafe_allow_html=True)
    if R.relations:
        rels = "".join(
            f'<div class="rel"><span class="rt">{r.get("head_text")}</span>'
            f'<span class="rarrow"> —[{r.get("type")}]→ </span>'
            f'<span class="rt">{r.get("tail_text")}</span></div>'
            for r in R.relations)
        st.markdown(f'<div class="relbox">{rels}</div>', unsafe_allow_html=True)
    src = "SpERT" if R.structure_source == "spert" else "lexicon (turn on SpERT for learned relations)"
    with st.expander(f"🕸 Problem knowledge graph ({src})"):
        components.html(KG.query_graph(R.entities, R.relations), height=440, scrolling=False)


def page_diagnose(rec_engine: Recommender, cfg: dict):
    st.markdown("### Diagnose")
    st.markdown('<div class="muted">Type a problem and press Enter. The system retrieves the closest '
                'historical work orders and grades its confidence — it never hides the evidence.</div>',
                unsafe_allow_html=True)
    q = st.text_input("Problem description", value="#2 intake gasket leaking",
                      placeholder="e.g. left magneto rpm drop on run up",
                      label_visibility="collapsed")
    if not q.strip():
        st.info("Enter a problem description above to get a recommendation.")
        return
    R = rec_engine.recommend(q, top_k=cfg["recommender"]["top_k"])

    st.markdown(T.badge_html(R.badge, R.lens), unsafe_allow_html=True)
    anchors = " ".join(f'<span class="pill">{c}</span>' for c in (R.components + R.faults)) or \
        '<span class="muted">no component/fault anchored</span>'
    st.markdown(f'<div style="margin:6px 0">Extracted: {anchors} '
                f'<span class="muted">· structure: {R.structure_source}</span></div>',
                unsafe_allow_html=True)

    _render_extraction(R)

    if R.structured_sentence:
        # the recommendation as a structured sentence, front and centre
        st.markdown(
            f'<div class="reco">➜ {R.structured_sentence}</div>'
            f'<div class="muted" style="margin:2px 0 14px">{R.headline_reason}</div>',
            unsafe_allow_html=True)
        if R.badge != "abstain" and st.button("➕ Promote to planning watchlist"):
            st.session_state.setdefault("plan_queue", [])
            st.session_state["plan_queue"].append(
                {"query": R.query, "recommendation": R.structured_sentence,
                 "action": R.headline_action,
                 "component": R.components[0] if R.components else ""})
            st.success("Added to planning watchlist.")

        if R.strategies:
            st.markdown("#### Recorded strategies for this problem")
            st.markdown('<div class="muted" style="margin-top:-6px;margin-bottom:8px">'
                        'Semantically similar problems were resolved in different ways. '
                        'Each strategy is a real, distinct response — what it means, how '
                        'often it was used, and its recorded outcomes.</div>',
                        unsafe_allow_html=True)
            shown_weak_header = False
            for s in R.strategies:
                if s.tier == "single_case" and not shown_weak_header:
                    st.markdown('<div class="muted" style="margin:12px 0 6px;font-weight:600">'
                                'Single-case options — recorded once, weak evidence, review only'
                                '</div>', unsafe_allow_html=True)
                    shown_weak_header = True
                _render_strategy(s)
    else:
        st.info(R.headline_reason)

    if R.negative_evidence:
        with st.expander("⚠ Negative / unresolved evidence (excluded from the recommendation)"):
            _render_cases(R.negative_evidence)
    with st.expander("All nearest cases (transparency)"):
        _render_cases(R.nearest_cases)


def page_insights(key: str, cfg: dict):
    st.markdown("### Insights")
    st.markdown('<div class="muted">How often things are recorded as failing, and how often '
                'each action is taken. Occurrence counts only — not reliability rates.</div>',
                unsafe_allow_html=True)
    tabs = st.tabs(["Recurring faults", "Component Pareto", "Fault modes",
                    "Actions", "Component × Fault", "Problem → Action", "Outcomes"])

    with tabs[0]:
        T.section("Chronic-defect register", "Recurring problem clusters, most frequent first.")
        wl = c_recurring(key, cfg["insights"]["recurring_min"], 40)
        st.dataframe(wl.drop(columns=["cluster_id"]).rename(columns={
            "problem": "Problem", "component": "Component", "fault": "Fault",
            "work_orders": "Work orders", "dominant_action": "Dominant action",
            "positive_outcomes": "Positive", "negative_outcomes": "Neg/unresolved",
            "outcome_unknown": "Unknown"}), hide_index=True, use_container_width=True, height=520)
    with tabs[1]:
        T.section("Component Pareto", "The vital few components behind most work orders.")
        st.plotly_chart(C.pareto(c_component_freq(key, 15), "component", "share_pct", "cumulative_pct"),
                        use_container_width=True, config={"displayModeBar": False})
    with tabs[2]:
        T.section("Fault modes", "Which failure conditions dominate.")
        st.plotly_chart(C.hbar(c_fault_freq(key, 15), "fault", "work_orders", C.SERIES[4], 460),
                        use_container_width=True, config={"displayModeBar": False})
    with tabs[3]:
        T.section("Action frequency", "What the fleet keeps doing.")
        st.plotly_chart(C.action_bars(c_action_freq(key), "action_family", "work_orders", 360),
                        use_container_width=True, config={"displayModeBar": False})
    with tabs[4]:
        T.section("Component × Fault", "Which components get which faults.")
        st.plotly_chart(C.heatmap(c_matrix(key, 8, 8)),
                        use_container_width=True, config={"displayModeBar": False})
    with tabs[5]:
        T.section("Problem → Action", "For a component, what actions were recorded.")
        sel = st.selectbox("Component", c_component_list(key, 25), label_visibility="collapsed")
        p2a = c_p2a(key, sel)
        if len(p2a):
            st.plotly_chart(C.action_bars(p2a, "action_family", "work_orders", 320),
                            use_container_width=True, config={"displayModeBar": False})
        else:
            st.info("No recorded actions for that component.")
    with tabs[6]:
        T.section("Outcome mix", "Recorded outcomes — mostly unknown, shown honestly.")
        st.plotly_chart(C.outcome_donut(c_outcome(key)), use_container_width=True,
                        config={"displayModeBar": False})


def page_kg(key: str, cfg: dict):
    st.markdown("### Knowledge Graph")
    st.markdown('<div class="muted">The corpus as a network — <b>components</b> (blue) carry '
                '<b>faults</b> (red) that <b>actions</b> (green) resolve. Click any node to light up '
                'its connections; pick a component below to focus on just its faults and actions.</div>',
                unsafe_allow_html=True)
    c0, c1, c2, c3 = st.columns([2, 1, 1, 1])
    comp_options = ["— whole corpus —"] + c_component_list(key, 30)
    focus = c0.selectbox("Focus on a component", comp_options, label_visibility="collapsed")
    focus = "" if focus.startswith("—") else focus
    top_c = c1.slider("Components", 5, 20, 10, disabled=bool(focus))
    top_f = c2.slider("Faults", 4, 15, 8)
    min_edge = c3.slider("Min co-occurrence", 1, 20, 1 if focus else 4)
    st.markdown(
        '<div class="kglegend">'
        '<span><span class="dot" style="background:#3987e5"></span> Component</span>'
        '<span><span class="dot" style="background:#e66767"></span> Fault</span>'
        '<span><span class="sq" style="background:#199e70"></span> Action family</span>'
        '<span class="muted">· click a node to highlight its neighbours</span>'
        '</div>', unsafe_allow_html=True)
    html = c_kg_html(key, top_c, top_f, min_edge, focus)
    components.html(html, height=640, scrolling=False)
    st.caption("Observed co-occurrences in the work orders — not causal or reliability claims.")


@st.cache_data(show_spinner=False)
def _run_eval(cfg_key: str, sample: int, use_reranker: bool):
    corpus = get_corpus(cfg_key)
    retr, rec = get_engine(cfg_key)
    rr = rec.reranker if (use_reranker and getattr(rec, "reranker", None)) else None
    return EV.evaluate(corpus.df, retr, sample=sample, reranker=rr)


def page_eval(cfg: dict, key: str):
    st.markdown("## Evaluation")
    st.markdown(
        '<div class="muted">Exploratory cluster-safe <b>leave-one-out</b>: each work order is hidden '
        '(with its whole near-duplicate cluster, so it can’t retrieve a copy of itself), '
        'and we check whether the recommended action <b>family</b> matches what was actually '
        'recorded. This measures <b>agreement with historical practice</b> — not technical '
        'correctness, which this data cannot support (no gold, outcomes mostly unknown). '
        'Final thesis claims must use the frozen train/dev/test evaluation launcher.</div>',
        unsafe_allow_html=True)
    cc1, cc2 = st.columns([3, 1])
    sample = cc1.slider("Sample size (larger = slower, more precise)", 300, 3000, 800, 100)
    use_rr = cc2.checkbox("Include reranker", value=False,
                          help="Route retrieval through the cross-encoder reranker (if loaded).")
    if not st.button("Run evaluation", type="primary"):
        st.info("Click **Run evaluation** to compute metrics on the current dataset "
                f"({os.path.basename(cfg['data'].get('csv_path',''))}). "
                "Tick *Include reranker* to measure its effect.")
        return
    with st.spinner(f"Running cluster-safe leave-one-out on {sample} work orders"
                    f"{' with reranker' if use_rr else ''}…"):
        res = _run_eval(key, sample, use_rr)
    if use_rr and not res.get("reranker"):
        st.warning("Reranker was requested but isn't loaded — showing base-retrieval results. "
                   "Check the reranker status (config + sentence-transformers).")

    # headline
    T.kpi_row([
        ("Macro-recall", f'{res["macro_recall"]:.0f}%', f'majority {res["baseline_majority_macro"]:.0f}%'),
        ("Top-1 agree", f'{res["top1_family_acc"]:.0f}%', f'majority {res["baseline_majority_acc"]:.0f}%'),
        ("Top-3 agree", f'{res["top3_family_acc"]:.0f}%', ""),
        ("MRR", f'{res["mrr"]:.2f}', ""),
        ("Evaluated", f'{res["n_evaluated"]:,}', "cluster-safe LOO"),
    ])
    st.markdown('<div class="muted">Because “Replace” dominates, report macro recall and '
                'per-family support alongside aggregate Top-1. Confidence tiers are diagnostic '
                'groups; calibration must be demonstrated separately with ECE, Brier score and '
                'risk–coverage results.</div>', unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    with c1:
        T.section("Coverage-at-confidence", "Where queries land, and accuracy vs majority in each tier.")
        tiers = ["strong", "moderate", "exploratory"]
        sys_acc = [res["tiers"][t]["top1_acc"] for t in tiers]
        maj_acc = [res["tiers"][t]["majority_acc"] for t in tiers]
        cov = [res["tiers"][t]["coverage_pct"] for t in tiers]
        labels = [f'{t.title()}\n{c:.0f}% of queries' for t, c in zip(tiers, cov)]
        fig = go.Figure()
        fig.add_bar(x=labels, y=sys_acc, name="System", marker_color=T.SERIES[0],
                    text=[f'{v:.0f}%' for v in sys_acc], textposition="outside")
        fig.add_bar(x=labels, y=maj_acc, name="Always-Replace", marker_color=T.MUTED,
                    text=[f'{v:.0f}%' for v in maj_acc], textposition="outside")
        fig.update_layout(height=340, barmode="group", paper_bgcolor="rgba(0,0,0,0)",
                          plot_bgcolor="rgba(0,0,0,0)", font=dict(color=T.INK2, size=12),
                          margin=dict(l=8, r=8, t=30, b=8),
                          legend=dict(orientation="h", y=1.15, bgcolor="rgba(0,0,0,0)"),
                          yaxis=dict(title="top-1 agreement %", range=[0, 105], gridcolor=T.HAIR),
                          xaxis=dict(gridcolor=T.HAIR))
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
    with c2:
        T.section("Per-family recall", "Balanced view: how well each action family is recovered.")
        pf = res["per_family_recall"]
        fams = sorted(pf, key=lambda f: pf[f]["n"], reverse=True)
        fig2 = go.Figure(go.Bar(
            x=[pf[f]["recall"] for f in fams][::-1], y=[f for f in fams][::-1],
            orientation="h", marker_color=T.SERIES[2],
            text=[f'{pf[f]["recall"]:.0f}% (n={pf[f]["n"]})' for f in fams][::-1],
            textposition="outside"))
        fig2.update_layout(height=340, paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                           font=dict(color=T.INK2, size=12), margin=dict(l=8, r=60, t=8, b=8),
                           xaxis=dict(title="recall %", range=[0, 115], gridcolor=T.HAIR),
                           yaxis=dict(gridcolor=T.HAIR))
        st.plotly_chart(fig2, use_container_width=True, config={"displayModeBar": False})

    st.markdown(
        '<div class="card"><b>How to read this:</b> these values measure agreement with recorded '
        'action families, not maintenance correctness. Compare against the majority baseline and '
        'report minority-family support. Do not call confidence tiers calibrated until the frozen '
        'evaluation produces ECE, Brier and risk–coverage evidence.</div>', unsafe_allow_html=True)


def page_guide():
    st.markdown("## Guide")
    st.markdown("""
This dashboard turns 6,169 aviation maintenance work orders into decision support.
It is **deterministic and traceable** — every recommendation maps to real historical
cases, and it grades its own confidence instead of bluffing.

**The seven pages**

- **Overview** — the shape of the corpus: totals, recurring problems, top components and actions.
- **Diagnose** — type a problem. You get: the entities/relations the model read, a
  **structured recommendation** with a confidence badge (Strong / Moderate / Exploratory),
  the **recorded strategies** (different actions used for the same problem, split into
  *corroborated* vs *single-case*), and the supporting cases by IDENT.
- **Insights** — how often things fail and how often each action is taken (counts, never rates).
- **Knowledge Graph** — the corpus as an interactive component→fault→action network.
- **Planning** — recurring-fault register → a grounded job card built only from recorded actions.

**How the recommendation is built** (no black box): normalize the query → extract structure
(SpERT if on, else lexicon) → hybrid retrieval (BM25 + TF-IDF + structured overlap, optional
dense) → optional cross-encoder **reranker** → confidence ladder → group into strategies →
compose a deterministic sentence. The confidence badge always reflects the primary strategy's
evidence.

**Turning on the models** (sidebar shows status):
- **SpERT** — start your service; the sidebar flips to *SpERT: ON* and the extracted
  entities/relations become model predictions with real relations.
- **Reranker** — set `retrieval.reranker_model` in `config.yaml` to a cross-encoder
  (e.g. `cross-encoder/ms-marco-MiniLM-L-6-v2`) or a development-selected checkpoint.

**Honest scope**: action families are derived heuristics (not gold labels); confidence
reflects historical support, not proven effectiveness; counts are occurrences, not failure
rates. Always verify against current approved maintenance data.
""")


def page_planning(df: pd.DataFrame, cfg: dict, key: str):
    st.markdown("### Planning & Support")
    st.markdown('<div class="muted">Turn recurring faults into standing plans, and draft a '
                'grounded job card from recorded actions (nothing invented).</div>',
                unsafe_allow_html=True)

    queue = st.session_state.get("plan_queue", [])
    if queue:
        T.section("Your planning watchlist", "Promoted from Diagnose.")
        st.dataframe(pd.DataFrame(queue), hide_index=True, use_container_width=True)
        if st.button("Clear watchlist"):
            st.session_state["plan_queue"] = []

    T.section("Recurring-fault register", "Pick a chronic problem to draft a job card.")
    wl = c_recurring(key, cfg["insights"]["recurring_min"], 40)
    labels = [f'{r.work_orders:>3} × {r.problem[:55]}' for r in wl.itertuples(index=False)]
    if not labels:
        st.info("No recurring clusters at the current threshold.")
        return
    pick = st.selectbox("Recurring problem", range(len(labels)), format_func=lambda i: labels[i])
    cid = wl.iloc[pick]["cluster_id"]
    card = W.job_card_for_cluster(df, cid)

    st.markdown(f"### Job card · {card.title}")
    T.kpi_row([
        ("Work orders", f"{card.work_orders:,}", ""),
        ("Problem groups", f"{card.problem_groups:,}", ""),
        ("Dominant action", card.dominant_action or "—", ""),
        ("Positive", f"{card.outcome_positive}", ""),
        ("Neg/unresolved", f"{card.outcome_negative}", ""),
        ("Unknown", f"{card.outcome_unknown}", ""),
    ])
    st.markdown("#### Recorded action steps (grounded, deduplicated)")
    if card.steps:
        for i, s in enumerate(card.steps, 1):
            st.markdown(f'{i}. {s["text"]}  '
                        f'<span class="caseid">{",".join(s["source_idents"])}</span>',
                        unsafe_allow_html=True)
    else:
        st.info("No positive/known-outcome action steps recorded for this cluster.")
    if card.references:
        st.markdown("**Cited references:** " + ", ".join(card.references))
    st.caption("Every step is a recorded historical action. Confirm against current approved "
               "maintenance data before use — this is decision support, not authorisation.")


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    T.setup_page()
    cfg = get_config()
    key = cfg_signature(cfg)
    corpus = get_corpus(key)
    retr, rec = get_engine(key)
    df = corpus.df

    # Live SpERT auto-detection (independent of config mode). Starting the
    # service any time is picked up on the next interaction.
    spert = SpERTClient(cfg["extraction"]["spert_url"])
    spert_on = spert.health()
    rec.client = spert if spert_on else None

    rr_on = bool(getattr(rec, "reranker", None)) and rec.reranker.available()
    ds = os.path.basename(cfg["data"].get("csv_path", ""))

    # ---- top bar: brand + live status chips ------------------------------- #
    hl, hr = st.columns([2.4, 3])
    with hl:
        st.markdown('<div class="brand">🛩️ <b>AviMaint-DSS</b>'
                    '<span class="brandsub">explainable maintenance decision support</span></div>',
                    unsafe_allow_html=True)
    with hr:
        spert_chip = (f'<span class="chip"><span class="sdot on"></span>SpERT on</span>' if spert_on
                      else '<span class="chip off"><span class="sdot off"></span>SpERT off</span>')
        rr_chip = (f'<span class="chip"><span class="sdot on"></span>Reranker on</span>' if rr_on
                   else '<span class="chip off"><span class="sdot off"></span>Reranker off</span>')
        st.markdown(
            f'<div class="chiprow">{spert_chip}{rr_chip}'
            f'<span class="chip data">{corpus.n:,} work orders · {ds}</span></div>',
            unsafe_allow_html=True)

    # ---- horizontal navbar ------------------------------------------------ #
    pages = ["Overview", "Diagnose", "Insights", "Knowledge Graph", "Planning", "Evaluation", "Guide"]
    icons = ["speedometer2", "search", "bar-chart-line", "diagram-3", "clipboard-check",
             "clipboard-data", "info-circle"]
    page = option_menu(
        None, pages, icons=icons, orientation="horizontal", default_index=0,
        styles={
            "container": {"padding": "6px", "background-color": "#151413",
                          "border": "1px solid #262624", "border-radius": "14px",
                          "margin": "2px 0 16px", "box-shadow": "0 1px 0 rgba(255,255,255,0.02)"},
            "nav-link": {"font-size": "13.5px", "color": "#b7b6ac", "padding": "9px 15px",
                         "margin": "0 2px", "border-radius": "9px", "white-space": "nowrap",
                         "font-weight": "500", "--hover-color": "#211f1e",
                         "transition": "all .15s ease"},
            "nav-link-selected": {"background-color": "#2a78d6", "color": "#ffffff",
                                  "font-weight": "600", "box-shadow": "0 2px 10px rgba(42,120,214,.35)"},
            "icon": {"font-size": "15px", "margin-right": "8px"},
        })

    if page == "Overview":
        page_overview(key, cfg)
    elif page == "Diagnose":
        page_diagnose(rec, cfg)
    elif page == "Insights":
        page_insights(key, cfg)
    elif page == "Knowledge Graph":
        page_kg(key, cfg)
    elif page == "Planning":
        page_planning(df, cfg, key)
    elif page == "Evaluation":
        page_eval(cfg, key)
    else:
        page_guide()

    # reranker load error (if any) — small footer note, not a blocker
    if getattr(rec, "reranker", None) is not None and not rr_on:
        with st.expander("⚠ Reranker configured but not loaded — why?"):
            st.caption(rec.reranker.last_error())


if __name__ == "__main__":
    main()

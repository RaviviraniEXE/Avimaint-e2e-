"""Diagnose why the reranker is ON or OFF. Run from the dashboard folder:

    python check_reranker.py
    python check_reranker.py "path/to/development-selected/reranker"

Prints the exact load result / error so you know what to fix.
"""
import sys
import yaml
from pathlib import Path
from core.reranker import CrossEncoderReranker

ROOT = Path(__file__).resolve().parent

if len(sys.argv) > 1:
    model = sys.argv[1]
else:
    cfg = yaml.safe_load(open(ROOT / "config.yaml", encoding="utf-8"))
    model = cfg["retrieval"].get("reranker_model") or ""

if not model:
    print("No reranker_model set in config.yaml (retrieval.reranker_model). "
          "Set it, e.g. cross-encoder/ms-marco-MiniLM-L-6-v2")
    raise SystemExit(0)

print(f"Trying to load reranker: {model}")
r = CrossEncoderReranker(model)
if r.available():
    print(f"OK — reranker LOADS. backend = {r.backend()}")
    scores = r.rerank("engine runs rough",
                      [(0, "engine runs rough on run up", 0.9),
                       (1, "intake gasket leaking", 0.4)])
    print("sanity rerank scores:", scores)
    print("\nThe dashboard will show Reranker: ON with this model.")
else:
    print("FAILED to load. Reason:\n  " + r.last_error())
    print("\nMost common fixes:")
    print("  1) pip install sentence-transformers   (installs torch + transformers too)")
    print("     -> make sure it's the SAME python you run the dashboard with")
    print("  2) generic model needs internet on first run to download")
    print("  3) a local checkpoint must contain config.json + model weights "
          "(model.safetensors or pytorch_model.bin) + tokenizer files")

"""Unified data layer: load work orders, derive structure, build clusters.

Progressive enhancement:
  * Always loads the raw CSV (IDENT, PROBLEM, ACTION).
  * If a SpERT service is reachable, structure is SpERT-derived; else lexicon.
  * If a prebuilt predictions file exists (JSONL of {ident, problem_pred, ...})
    it is used without re-running the model.
Results are cached to `data/cache/` keyed by CSV signature + extraction mode.
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from . import normalize as N
from .textnorm import Normalizer
from .extraction import SpERTClient, extract_structure, spert_to_structure, rule_structure


def _sig(path: Path, mode: str, norm: bool) -> str:
    st = path.stat()
    raw = f"{path.name}:{st.st_size}:{int(st.st_mtime)}:{mode}:norm{norm}:v2"
    return hashlib.sha1(raw.encode()).hexdigest()[:16]


@dataclass
class Corpus:
    df: pd.DataFrame
    mode: str  # "spert" | "rule" | "predictions"
    normalizer: Normalizer | None = None

    # ---- convenience accessors -------------------------------------------- #
    @property
    def n(self) -> int:
        return len(self.df)

    @property
    def n_clusters(self) -> int:
        return self.df["cluster_id"].nunique()

    def cluster_support(self) -> pd.Series:
        return self.df.groupby("cluster_id").size()


def _build_dataframe(csv_path: Path, mode: str, spert_url: str,
                     predictions_path: Path | None,
                     normalizer: Normalizer | None) -> pd.DataFrame:
    df = pd.read_csv(csv_path, encoding="utf-8-sig", dtype=str, keep_default_na=False)
    # tolerate column-name variants
    cols = {c.lower().strip(): c for c in df.columns}
    ident_c = cols.get("ident") or list(df.columns)[0]
    prob_c = cols.get("problem") or list(df.columns)[1]
    act_c = cols.get("action") or list(df.columns)[2]
    df = df.rename(columns={ident_c: "ident", prob_c: "problem", act_c: "action"})
    df = df[["ident", "problem", "action"]].copy()
    df["problem"] = df["problem"].fillna("").astype(str)
    df["action"] = df["action"].fillna("").astype(str)

    # per-field normalization (raw text kept for display/provenance)
    if normalizer is not None:
        df["problem_clean"] = df["problem"].map(normalizer.normalize)
        df["action_clean"] = df["action"].map(normalizer.normalize)
    else:
        df["problem_clean"] = df["problem"]
        df["action_clean"] = df["action"]

    # optional prebuilt predictions {ident: problem_pred_dict}
    preds: dict[str, dict] = {}
    if predictions_path and predictions_path.is_file():
        with open(predictions_path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                rec = json.loads(line)
                key = str(rec.get("ident") or rec.get("case_id") or rec.get("id"))
                preds[key] = rec

    client = None
    if mode == "spert" and not preds:
        client = SpERTClient(spert_url)
        if not client.health():
            client = None  # fall back to lexicon

    comps, faults, locs, fams, roles, outs, srcs, entity_types, relation_types = (
        [] for _ in range(9)
    )
    for row in df.itertuples(index=False):
        ident = row.ident
        problem, action = row.problem_clean, row.action_clean  # normalized for matching
        if preds and str(ident) in preds:
            rec = preds[str(ident)]
            st = spert_to_structure(rec.get("problem_pred") or rec, action,
                                    rec.get("action_pred"))
        elif client is not None:
            st = extract_structure(problem, action, client)
        else:
            st = rule_structure(problem, action)
        comps.append(st.components)
        faults.append(st.faults)
        locs.append(st.locations)
        fams.append(st.action_family)
        roles.append(st.action_role)
        outs.append(st.outcome)
        srcs.append(st.source)
        entity_types.append(sorted({str(e.get("type", "")) for e in st.entities if e.get("type")}))
        relation_types.append(sorted({str(r.get("type", "")) for r in st.relations if r.get("type")}))

    df["components"] = comps
    df["faults"] = faults
    df["locations"] = locs
    df["action_family"] = fams
    df["action_role"] = roles
    df["outcome"] = outs
    df["source"] = srcs
    # Problem-side signatures only: recorded action text is never part of a
    # retrieval query representation.
    df["problem_entity_types"] = entity_types
    df["problem_relation_types"] = relation_types
    df["problem_norm"] = df["problem_clean"].map(N.normalize_problem)
    df["cluster_id"] = df["problem_norm"].factorize()[0].astype(str)
    # primary component / fault for single-value grouping
    df["component"] = df["components"].map(lambda xs: xs[0] if xs else "(unspecified)")
    df["fault"] = df["faults"].map(lambda xs: xs[0] if xs else "(unspecified)")
    return df


def load_corpus(csv_path: str | os.PathLike, mode: str = "rule",
                spert_url: str = "http://127.0.0.1:8765",
                predictions_path: str | os.PathLike | None = None,
                normalize: bool = True,
                use_cache: bool = True) -> Corpus:
    csv_path = Path(csv_path)
    pred_path = Path(predictions_path) if predictions_path else None
    eff_mode = "predictions" if (pred_path and pred_path.is_file()) else mode
    normalizer = Normalizer.from_dir(csv_path.parent) if normalize else None
    cache_dir = csv_path.parent / "cache"
    cache_dir.mkdir(exist_ok=True)
    cache_file = cache_dir / f"corpus_{_sig(csv_path, eff_mode, normalize)}.parquet"

    if use_cache and cache_file.is_file():
        df = pd.read_parquet(cache_file)
        return Corpus(df=df, mode=eff_mode, normalizer=normalizer)

    df = _build_dataframe(csv_path, mode, spert_url, pred_path, normalizer)
    if use_cache:
        try:
            df.to_parquet(cache_file)
        except Exception:
            pass
    return Corpus(df=df, mode=eff_mode, normalizer=normalizer)

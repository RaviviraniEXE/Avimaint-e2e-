"""The recommender: retrieval -> action aggregation -> confidence ladder.

The core fix vs. the old system: retrieval ALWAYS returns nearest cases; the
confidence ladder decides the *badge*, never whether anything is shown. A
widening fallback (problem -> component -> fault) means a one-off problem still
returns a labelled, grounded answer instead of "insufficient evidence".
"""
from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from . import normalize as N
from . import compose as X
from . import strategies as S
from .extraction import SpERTClient, extract_structure
from .retrieval import Retriever

# ladder thresholds (tunable; exposed in config)
STRONG_SCORE = 0.42
MODERATE_SCORE = 0.22
MIN_SCORE = 0.06


@dataclass
class CaseEvidence:
    ident: str
    problem: str
    action: str
    action_family: str
    outcome: str
    cluster_id: str
    score: float


@dataclass
class Recommendation:
    query: str
    components: list[str]
    faults: list[str]
    badge: str                      # strong | moderate | exploratory | abstain
    lens: str                       # problem | component | fault | none
    headline_action: str
    headline_reason: str
    support_clusters: int
    structured_sentence: str = ""   # composed imperative recommendation
    strategies: list = field(default_factory=list)   # list[Strategy] (different actions)
    recommended_cases: list[CaseEvidence] = field(default_factory=list)
    alternatives: list[dict] = field(default_factory=list)
    nearest_cases: list[CaseEvidence] = field(default_factory=list)
    negative_evidence: list[CaseEvidence] = field(default_factory=list)
    structure_source: str = "rule"
    entities: list = field(default_factory=list)     # SpERT/lexicon entities for display
    relations: list = field(default_factory=list)    # SpERT/lexicon relations for display


_BADGE_LABEL = {
    "strong": "Strong — corroborated by multiple independent cases",
    "moderate": "Moderate — suggested, verify against current data",
    "exploratory": "Exploratory — no strong precedent; closest cases shown",
    "abstain": "No match found in the corpus",
}


def badge_label(badge: str) -> str:
    return _BADGE_LABEL.get(badge, badge)


class Recommender:
    def __init__(self, df: pd.DataFrame, retriever: Retriever,
                 spert_client: SpERTClient | None = None, normalizer=None,
                 reranker=None, strong_score: float = STRONG_SCORE,
                 moderate_score: float = MODERATE_SCORE,
                 widening_score: float = MIN_SCORE):
        self.df = df.reset_index(drop=True)
        self.r = retriever
        self.client = spert_client
        self.normalizer = normalizer
        self.reranker = reranker
        self.strong_score = float(strong_score)
        self.moderate_score = float(moderate_score)
        self.widening_score = float(widening_score)

    def _case(self, idx: int, score: float) -> CaseEvidence:
        row = self.df.iloc[idx]
        return CaseEvidence(
            ident=str(row["ident"]), problem=row["problem"], action=row["action"],
            action_family=row["action_family"], outcome=row["outcome"],
            cluster_id=str(row["cluster_id"]), score=round(float(score), 3),
        )

    def _aggregate(self, cases: list[CaseEvidence]) -> tuple[str, int, list[dict]]:
        """Group eligible cases by action family; support = distinct clusters."""
        fams: dict[str, dict] = {}
        for c in cases:
            if c.action_family == "Other":
                continue
            if c.outcome in ("negative", "mixed"):
                continue  # excluded from recommendation, kept as negative evidence
            f = fams.setdefault(c.action_family, {"score": 0.0, "clusters": set(), "example": c})
            f["score"] += c.score
            f["clusters"].add(c.cluster_id)
            if c.score > f["example"].score:
                f["example"] = c
        ranked = sorted(fams.items(), key=lambda kv: (len(kv[1]["clusters"]), kv[1]["score"]),
                        reverse=True)
        if not ranked:
            return "", 0, []
        headline, meta = ranked[0]
        alts = [{"action_family": k, "support_clusters": len(v["clusters"]),
                 "example_action": v["example"].action, "example_ident": v["example"].ident}
                for k, v in ranked[1:4]]
        return headline, len(meta["clusters"]), alts

    def _scoped_support(self, headline: str, q_comp: list[str], q_fault: list[str]) -> int:
        """Distinct clusters in the FULL corpus that corroborate this action for a
        matching component (or fault) — true independent support, not just top-K."""
        if not headline:
            return 0
        df = self.df
        fam = df["action_family"] == headline
        ok_out = ~df["outcome"].isin(["negative", "mixed"])
        if q_comp:
            anchor = df["components"].map(lambda xs: any(c in xs for c in q_comp))
        elif q_fault:
            anchor = df["faults"].map(lambda xs: any(f in xs for f in q_fault))
        else:
            return 0
        sub = df[fam & ok_out & anchor]
        return int(sub["cluster_id"].nunique())

    def _order_cases(self, cases: list[CaseEvidence], q_comp: list[str]) -> list[CaseEvidence]:
        def key(c: CaseEvidence):
            comp_match = 1 if any(k in c.problem.lower() for k in q_comp) else 0
            out_rank = {"positive": 2, "unknown": 1}.get(c.outcome, 0)
            return (comp_match, out_rank, c.score)
        return sorted(cases, key=key, reverse=True)

    def _component_lens(self, q_comp: list[str], top_k: int = 40) -> list[CaseEvidence]:
        if not q_comp:
            return []
        mask = self.df["components"].map(lambda xs: any(c in xs for c in q_comp))
        sub = self.df[mask].head(top_k)
        return [self._case(i, 0.2) for i in sub.index]

    def _fault_lens(self, q_fault: list[str], top_k: int = 40) -> list[CaseEvidence]:
        if not q_fault:
            return []
        mask = self.df["faults"].map(lambda xs: any(f in xs for f in q_fault))
        sub = self.df[mask].head(top_k)
        return [self._case(i, 0.15) for i in sub.index]

    def _strategy_pool(self, q_comp: list[str], q_fault: list[str],
                       fallback_idx: list[int]) -> "pd.DataFrame":
        df = self.df
        ok = ~df["outcome"].isin(["negative", "mixed"])
        if q_comp:
            comp_m = df["components"].map(lambda xs: any(c in xs for c in q_comp))
            if q_fault:
                both = df[comp_m & ok & df["faults"].map(lambda xs: any(f in xs for f in q_fault))]
                if len(both) >= 3:
                    return both
            comp_only = df[comp_m & ok]
            if len(comp_only) >= 1:
                return comp_only
        if q_fault:
            fault_m = df[df["faults"].map(lambda xs: any(f in xs for f in q_fault)) & ok]
            if len(fault_m) >= 1:
                return fault_m
        return df.loc[[i for i in fallback_idx if i in df.index]]

    def _attach_strategies(self, rec: Recommendation, q_comp, q_fault, q_loc, hit_idx):
        pool = self._strategy_pool(q_comp, q_fault, hit_idx)
        primary_fault = q_fault[0] if q_fault else None
        strategies = S.build_strategies(pool, q_comp, q_loc, primary_fault)
        # Primary = the headline family IF it is corroborated; otherwise the top
        # corroborated strategy; otherwise the first available. Never surface a
        # single-case option as the primary recommendation.
        if strategies:
            for s in strategies:
                s.is_primary = False
            corr = [s for s in strategies if s.tier == "corroborated"]
            primary = next((s for s in corr if s.family == rec.headline_action),
                           corr[0] if corr else strategies[0])
            strategies.remove(primary)
            strategies.insert(0, primary)
            primary.is_primary = True
            rec.headline_action = primary.family  # keep reason + sentence consistent
        rec.strategies = strategies
        if rec.strategies:
            p = rec.strategies[0]
            rec.structured_sentence = p.sentence
            # Reconcile the confidence badge with the primary strategy's support,
            # so the grade always reflects the actual recommendation (thesis-safe).
            rec.support_clusters = p.support_clusters
            if p.tier == "single_case":
                if rec.badge in ("strong", "moderate"):
                    rec.badge = "exploratory"
                rec.headline_reason = (f"Only one recorded case supports “{p.family}” for this "
                                       f"problem — treat as exploratory, verify against current data.")
            elif rec.badge == "strong":
                rec.headline_reason = (f"{p.support_clusters} independent problem groups record "
                                       f"“{p.family}” for a matching component; strong match.")
            elif rec.badge == "moderate":
                rec.headline_reason = (f"{p.support_clusters} independent group(s) record "
                                       f"“{p.family}”; verify against current approved data.")
        elif rec.headline_action:
            rec.structured_sentence = X.compose_sentence(
                rec.headline_action, X.build_target(q_comp, q_loc), primary_fault)
        return rec

    def recommend(self, query: str, top_k: int = 25) -> Recommendation:
        raw_query = query
        # Normalize the query so it matches the (possibly pre-normalized) corpus.
        # Uses the loaded lists if present, else the built-in map — so even when
        # the corpus CSV is already System-C normalized (normalize=false), a typed
        # "l/h mag" still matches the corpus "left magneto".
        if self.normalizer:
            nq = self.normalizer.normalize(query)
        else:
            from .textnorm import normalize_text
            nq = normalize_text(query)
        st = extract_structure(nq, "", self.client)
        q_comp = st.components or N.find_components(nq)
        q_loc = st.locations or N.find_locations(nq)
        q_fault = st.faults or ([N.issue_family(nq)] if N.issue_family(nq) else [])
        q_fault = [f for f in q_fault if f]

        # retrieve a deeper pool when a reranker is active, then rerank to top_k
        depth = max(top_k, 50) if (self.reranker and self.reranker.available()) else top_k
        hits = self.r.search(nq, q_comp, q_fault, top_k=depth)
        if self.reranker and self.reranker.available() and hits:
            cand = [(h.idx, self.df.iloc[h.idx]["problem_norm"], h.score) for h in hits]
            order = self.reranker.rerank(nq, cand)          # [(idx, blended)]
            by_idx = {h.idx: h for h in hits}
            hits = []
            for idx, sc in order[:top_k]:
                h = by_idx[idx]
                h.score = float(sc)
                hits.append(h)
        else:
            hits = hits[:top_k]
        hit_idx = [h.idx for h in hits]
        nearest = [self._case(h.idx, h.score) for h in hits]
        negatives = [c for c in nearest if c.outcome in ("negative", "mixed")][:3]

        rec = Recommendation(
            query=query, components=q_comp, faults=q_fault,
            badge="abstain", lens="none", headline_action="",
            headline_reason="", support_clusters=0,
            nearest_cases=nearest[:8], negative_evidence=negatives,
            structure_source=st.source, entities=st.entities, relations=st.relations,
        )
        if not hits or hits[0].score < self.widening_score:
            return self._widen(rec, q_comp, q_fault, q_loc, hit_idx)

        top_score = hits[0].score
        comp_anchor = bool(q_comp) and any(
            c in self.df.iloc[hits[0].idx]["components"] for c in q_comp)
        headline, _local, alts = self._aggregate(nearest)
        # true independent support = component/fault-scoped distinct clusters (corpus-wide)
        support = self._scoped_support(headline, q_comp, q_fault)
        rec.headline_action = headline
        rec.support_clusters = support
        rec.alternatives = alts
        rec.recommended_cases = self._order_cases(
            [c for c in nearest if c.action_family == headline
             and c.outcome not in ("negative", "mixed")], q_comp)[:5]
        rec.lens = "problem"
        has_anchor = bool(q_comp or q_fault)

        if (headline and has_anchor and comp_anchor
                and support >= 3 and top_score >= self.strong_score):
            rec.badge = "strong"
            rec.headline_reason = (f"{support} independent problem groups record “{headline}” for a "
                                   f"matching component; strong textual match.")
        elif headline and bool(q_comp) and support >= 1 and top_score >= self.moderate_score:
            rec.badge = "moderate"
            rec.headline_reason = (f"{support} independent group(s) record “{headline}”; "
                                   f"verify against current approved data.")
        elif headline and top_score >= self.moderate_score and not bool(q_comp):
            # text match but no concrete component to anchor on -> cap at exploratory
            rec.badge = "exploratory"
            rec.headline_reason = (f"Closest cases most often record “{headline}”, but no specific "
                                   f"component could be anchored — treat as exploratory.")
        else:
            return self._widen(rec, q_comp, q_fault, q_loc, hit_idx)
        return self._attach_strategies(rec, q_comp, q_fault, q_loc, hit_idx)

    def _widen(self, rec: Recommendation, q_comp: list[str], q_fault: list[str],
               q_loc: list[str] | None = None, hit_idx: list[int] | None = None) -> Recommendation:
        q_loc = q_loc or []
        hit_idx = hit_idx or []
        # component lens
        for lens_name, cases in (("component", self._component_lens(q_comp)),
                                 ("fault", self._fault_lens(q_fault))):
            if not cases:
                continue
            headline, support, alts = self._aggregate(cases)
            if headline:
                rec.badge = "exploratory"
                rec.lens = lens_name
                rec.headline_action = headline
                rec.support_clusters = support
                rec.alternatives = alts
                rec.recommended_cases = [c for c in cases
                                         if c.action_family == headline
                                         and c.outcome not in ("negative", "mixed")][:5]
                anchor = ", ".join(q_comp) if lens_name == "component" else ", ".join(q_fault)
                rec.headline_reason = (
                    f"No strong precedent for this exact problem. Widened to "
                    f"{lens_name} “{anchor}”: history most often records “{headline}” "
                    f"({support} cluster(s)).")
                return self._attach_strategies(rec, q_comp, q_fault, q_loc, hit_idx)
        # nothing at all
        rec.badge = "exploratory" if rec.nearest_cases else "abstain"
        rec.lens = "problem" if rec.nearest_cases else "none"
        rec.headline_reason = ("Closest historical cases shown; no confident action pattern."
                               if rec.nearest_cases else
                               "No comparable historical work orders found.")
        return self._attach_strategies(rec, q_comp, q_fault, q_loc, hit_idx)

"""Hybrid retrieval: BM25 + word/char TF-IDF + structured anchor overlap.

Dense embeddings (sentence-transformers all-mpnet-base-v2) are optional and off
by default; enable via config when the package + model are available. Rank
position never creates strong evidence on its own -- absolute channel scores are
fused, matching the frozen system's design.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

import numpy as np
import pandas as pd
from rank_bm25 import BM25Okapi
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

_TOK = re.compile(r"[a-z0-9#]+")


def _tok(text: str) -> list[str]:
    return _TOK.findall((text or "").lower())


@dataclass
class Hit:
    idx: int
    score: float
    text_sim: float
    struct: float


class Retriever:
    def __init__(self, df: pd.DataFrame, weights: dict | None = None,
                 dense_model: str | None = None):
        self.df = df.reset_index(drop=True)
        self.docs = self.df["problem_norm"].tolist()
        self.weights = weights or {"bm25": 0.34, "word": 0.24, "char": 0.14, "struct": 0.28}
        self._bm25 = BM25Okapi([_tok(d) for d in self.docs])
        self._word = TfidfVectorizer(analyzer="word", ngram_range=(1, 2), min_df=1)
        self._wm = self._word.fit_transform(self.docs)
        self._char = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=1)
        self._cm = self._char.fit_transform(self.docs)
        self._comp = self.df["components"].tolist()
        self._fault = self.df["faults"].tolist()
        self._entity_types = self.df.get(
            "problem_entity_types", pd.Series([[] for _ in range(len(self.df))])
        ).tolist()
        self._relation_types = self.df.get(
            "problem_relation_types", pd.Series([[] for _ in range(len(self.df))])
        ).tolist()
        self._dense = None
        self._demb = None
        if dense_model:
            self._init_dense(dense_model)

    def _init_dense(self, model_name: str) -> None:
        try:
            from sentence_transformers import SentenceTransformer
            self._dense = SentenceTransformer(model_name)
            self._demb = self._dense.encode(self.docs, normalize_embeddings=True,
                                            show_progress_bar=False)
            self.weights = {"bm25": 0.26, "word": 0.16, "char": 0.10,
                            "dense": 0.24, "struct": 0.24}
        except Exception:
            self._dense = None

    @staticmethod
    def _norm(a: np.ndarray) -> np.ndarray:
        m = float(a.max()) if a.size else 0.0
        return a / m if m > 0 else a

    def _struct_overlap(self, q_comp: list[str], q_fault: list[str],
                        q_entity_types: list[str] | None = None,
                        q_relation_types: list[str] | None = None) -> np.ndarray:
        qc, qf = set(q_comp), set(q_fault)
        qe, qr = set(q_entity_types or []), set(q_relation_types or [])
        out = np.zeros(len(self.docs))
        if not qc and not qf and not qe and not qr:
            return out
        for i in range(len(self.docs)):
            cc = qc & set(self._comp[i])
            ff = qf & set(self._fault[i])
            c_s = len(cc) / len(qc) if qc else 0.0
            f_s = len(ff) / len(qf) if qf else 0.0
            e_s = len(qe & set(self._entity_types[i])) / len(qe) if qe else 0.0
            r_s = len(qr & set(self._relation_types[i])) / len(qr) if qr else 0.0
            values = (c_s, f_s, e_s, r_s)
            enabled = (bool(qc), bool(qf), bool(qe), bool(qr))
            weights = (0.40, 0.30, 0.15, 0.15)
            denominator = sum(weight for weight, use in zip(weights, enabled) if use)
            out[i] = (
                sum(weight * value for weight, value, use in zip(weights, values, enabled) if use)
                / denominator if denominator else 0.0
            )
        return out

    def search(self, query: str, q_comp: list[str], q_fault: list[str],
               top_k: int = 25, q_entity_types: list[str] | None = None,
               q_relation_types: list[str] | None = None) -> list[Hit]:
        qt = _tok(query)
        bm = self._norm(np.asarray(self._bm25.get_scores(qt)))
        wm = self._norm(cosine_similarity(self._word.transform([query]), self._wm).ravel())
        cm = self._norm(cosine_similarity(self._char.transform([query]), self._cm).ravel())
        st = self._struct_overlap(q_comp, q_fault, q_entity_types, q_relation_types)
        w = self.weights
        text_sim = w["bm25"] * bm + w["word"] * wm + w["char"] * cm
        if self._dense is not None:
            qd = self._dense.encode([query], normalize_embeddings=True, show_progress_bar=False)
            dn = self._norm((self._demb @ qd.T).ravel())
            text_sim = text_sim + w.get("dense", 0.0) * dn
        total = text_sim + w["struct"] * st
        order = np.argsort(-total)[:top_k]
        return [Hit(int(i), float(total[i]), float(text_sim[i]), float(st[i])) for i in order]

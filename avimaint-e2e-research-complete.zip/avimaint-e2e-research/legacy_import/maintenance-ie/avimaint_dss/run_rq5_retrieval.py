"""Run RQ5 retrieval ablations with problem-only, cluster-safe queries."""

from __future__ import annotations

import argparse
import json

from research_evaluation import (
    PROJECT_ROOT,
    REPRESENTATIONS,
    SYSTEM_FILES,
    evaluate_partition,
    load_system,
    protocol_frames,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", choices=["loo", "frozen"], default="loo")
    parser.add_argument(
        "--systems", nargs="+", choices=sorted(SYSTEM_FILES), default=sorted(SYSTEM_FILES)
    )
    parser.add_argument(
        "--representations",
        nargs="+",
        choices=sorted(REPRESENTATIONS),
        default=sorted(REPRESENTATIONS),
    )
    parser.add_argument(
        "--limit", type=int, default=0, help="Smoke-test limit; use 0 for the thesis run"
    )
    args = parser.parse_args()
    output = PROJECT_ROOT / "outputs/runs/rq5_leakage_safe_case_retrieval" / args.protocol
    output.mkdir(parents=True, exist_ok=True)
    summary = {}
    for system in args.systems:
        frame = load_system(system)
        candidates, queries = protocol_frames(frame, args.protocol, "test")
        if args.limit:
            queries = queries.head(args.limit)
        for representation in args.representations:
            print(f"RQ5 {args.protocol}: {system} / {representation}")
            metrics, predictions = evaluate_partition(candidates, queries, representation)
            key = f"{system}__{representation}"
            summary[key] = {"system": system, "protocol": args.protocol, **metrics}
            predictions.to_csv(output / f"predictions_{key}.csv", index=False)
    (output / "metrics.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(f"Saved {len(summary)} RQ5 runs -> {output}")


if __name__ == "__main__":
    main()

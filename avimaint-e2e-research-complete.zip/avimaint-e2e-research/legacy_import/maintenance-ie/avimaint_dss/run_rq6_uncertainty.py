"""Calibrate RQ6 retrieval confidence on DEV and evaluate once on TEST."""

from __future__ import annotations

import argparse
import json

import numpy as np
from research_evaluation import (
    PROJECT_ROOT,
    calibration_features,
    confidence_bins,
    evaluate_partition,
    expected_calibration_error,
    load_system,
    protocol_frames,
    risk_coverage,
)
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--system", choices=["raw", "rules_then_byt5"], default="rules_then_byt5")
    parser.add_argument(
        "--representation", choices=["bm25", "tfidf", "structure", "hybrid"], default="hybrid"
    )
    args = parser.parse_args()
    frame = load_system(args.system)
    candidates, dev_queries = protocol_frames(frame, "frozen", "dev")
    _, dev = evaluate_partition(candidates, dev_queries, args.representation)
    _, test_queries = protocol_frames(frame, "frozen", "test")
    test_metrics, test = evaluate_partition(candidates, test_queries, args.representation)

    x_dev, y_dev = calibration_features(dev), dev["top1_correct"].astype(int).to_numpy()
    x_test, y_test = calibration_features(test), test["top1_correct"].astype(int).to_numpy()
    if len(np.unique(y_dev)) < 2:
        raise SystemExit(
            "DEV correctness contains one class; logistic calibration is not identifiable"
        )
    calibrator = make_pipeline(
        StandardScaler(), LogisticRegression(max_iter=2000, random_state=42)
    ).fit(x_dev, y_dev)
    probability = calibrator.predict_proba(x_test)[:, 1]
    test["calibrated_probability"] = probability
    metrics = {
        "system": args.system,
        "representation": args.representation,
        "calibration_population": "frozen development",
        "evaluation_population": "frozen test",
        "development_queries": int(len(dev)),
        "test_queries": int(len(test)),
        "ece_10_bins": expected_calibration_error(y_test, probability, 10),
        "brier_score": float(brier_score_loss(y_test, probability)),
        "error_rate_by_confidence_bin": confidence_bins(y_test, probability, 10),
        "risk_coverage": risk_coverage(y_test, probability),
        "evidence_coverage": float(test["predicted_family"].astype(bool).mean()),
        "provenance_completeness": float(
            test[["ident", "cluster_id"]].astype(str).ne("").all(axis=1).mean()
        ),
        "retrieval_metrics": test_metrics,
        "interface_policy": (
            "confidence changes badges, warnings and requested context; "
            "nearest traceable cases remain visible"
        ),
    }
    output = PROJECT_ROOT / "outputs/runs/rq6_auditable_planning_support"
    output.mkdir(parents=True, exist_ok=True)
    test.to_csv(output / "calibrated_test_predictions.csv", index=False)
    (output / "uncertainty_metrics.json").write_text(
        json.dumps(metrics, indent=2) + "\n", encoding="utf-8"
    )
    print(f"RQ6 calibrated on DEV and evaluated on TEST -> {output}")


if __name__ == "__main__":
    main()

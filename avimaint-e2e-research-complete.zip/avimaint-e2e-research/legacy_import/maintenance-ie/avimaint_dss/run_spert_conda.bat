@echo off
title AviMaint SpERT service (conda)
cd /d "%~dp0"
for %%I in ("%~dp0..") do set "PROJECT_ROOT=%%~fI"

REM ====== Your existing SpERT conda env (from `conda env list`) ======
set "SPERT_ENV=avimaint-spert"
REM ===================================================================

echo Activating conda env "%SPERT_ENV%" and starting SpERT on :8765 ...
call conda activate %SPERT_ENV%

REM NOTE: `conda activate` can report a nonzero exit code even when it
REM succeeds, so we do NOT gate on errorlevel here. If the env name is
REM wrong, conda prints its own error above and python won't find the deps.

python services\spert_query_service.py --project-root "%PROJECT_ROOT%"
echo.
echo (SpERT service stopped.)
pause

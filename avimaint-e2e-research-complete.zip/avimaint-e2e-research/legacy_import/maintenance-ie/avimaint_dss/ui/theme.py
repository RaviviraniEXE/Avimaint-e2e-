"""Dark theme, palette, and small HTML components (KPI tiles, badges)."""
from __future__ import annotations

import streamlit as st

# Validated palette (dark surface) ------------------------------------------ #
PLANE = "#0d0d0d"
SURFACE = "#1a1a19"
SURFACE2 = "#211f1e"
INK = "#ffffff"
INK2 = "#c3c2b7"
MUTED = "#898781"
HAIR = "#2c2c2a"

SERIES = ["#3987e5", "#d95926", "#199e70", "#c98500", "#d55181", "#008300", "#9085e9", "#e66767"]
STATUS = {"good": "#0ca30c", "warning": "#fab219", "serious": "#ec835a", "critical": "#d03b3b"}

BADGE = {
    "strong": ("#0ca30c", "Strong"),
    "moderate": ("#fab219", "Moderate"),
    "exploratory": ("#8a8a83", "Exploratory"),
    "abstain": ("#d03b3b", "No match"),
}


def setup_page():
    st.set_page_config(page_title="AviMaint-DSS", page_icon="🛩️", layout="wide",
                       initial_sidebar_state="collapsed")
    st.markdown(f"""
    <style>
      .stApp {{ background:{PLANE}; -webkit-font-smoothing:antialiased; }}
      section[data-testid="stSidebar"] {{ display:none; }}
      header[data-testid="stHeader"] {{ background:transparent; }}
      h1,h2,h3,h4 {{ letter-spacing:-0.015em; }}
      h3 {{ font-size:22px; margin:2px 0 2px; }}
      .block-container {{ padding-top:1.3rem; max-width:1340px; }}
      .brand {{ font-size:20px; color:{INK}; display:flex; align-items:center; gap:11px;
                height:100%; font-weight:700; }}
      .brand .brandsub {{ font-size:12.5px; color:{MUTED}; font-weight:400; }}
      .chiprow {{ display:flex; gap:8px; justify-content:flex-end; flex-wrap:wrap; align-items:center;
                  height:100%; min-height:40px; }}
      .chip {{ display:inline-flex; align-items:center; gap:6px; font-size:12px; color:{INK2};
               background:{SURFACE}; border:1px solid {HAIR}; padding:5px 12px; border-radius:999px; }}
      .chip.off {{ color:{MUTED}; }}
      .chip.data {{ color:{MUTED}; }}
      .kpi-row {{ display:flex; flex-wrap:wrap; gap:14px; margin:6px 0 18px; }}
      .kpi {{ flex:1 1 150px; background:linear-gradient(180deg,{SURFACE2},{SURFACE});
              border:1px solid {HAIR}; border-radius:14px; padding:16px 18px;
              transition:border-color .15s ease, transform .15s ease; }}
      .kpi:hover {{ border-color:#3a3a37; transform:translateY(-1px); }}
      .kpi .v {{ font-size:30px; font-weight:700; color:{INK}; line-height:1.1;
                 font-variant-numeric:tabular-nums; }}
      .kpi .l {{ font-size:12px; color:{MUTED}; margin-top:6px; text-transform:uppercase;
                 letter-spacing:.05em; }}
      .kpi .s {{ font-size:12px; color:{INK2}; margin-top:2px; }}
      .badge {{ display:inline-block; font-size:13px; font-weight:700; padding:6px 14px;
                border-radius:999px; color:#0d0d0d; }}
      .lens {{ display:inline-block; font-size:11px; font-weight:600; padding:3px 9px;
               border-radius:6px; background:{SURFACE2}; color:{INK2}; border:1px solid {HAIR};
               text-transform:uppercase; letter-spacing:.04em; margin-left:8px; }}
      .card {{ background:{SURFACE}; border:1px solid {HAIR}; border-radius:14px;
               padding:16px 18px; margin-bottom:12px; }}
      .caseid {{ font-family:ui-monospace,monospace; font-size:12px; color:{SERIES[0]};
                 background:{SURFACE2}; padding:1px 7px; border-radius:5px; }}
      .muted {{ color:{MUTED}; font-size:13px; }}
      .pill {{ display:inline-block; font-size:11px; padding:2px 8px; border-radius:6px;
               background:{SURFACE2}; color:{INK2}; border:1px solid {HAIR}; margin-right:5px; }}
      .stDataFrame {{ border:1px solid {HAIR}; border-radius:10px; }}
      div[data-testid="stMetricValue"] {{ font-size:26px; }}
      .reco {{ font-size:22px; font-weight:700; color:{INK}; line-height:1.35;
               background:linear-gradient(90deg,rgba(57,135,229,.16),rgba(57,135,229,.02));
               border-left:3px solid {SERIES[0]}; border-radius:10px; padding:14px 18px;
               margin:10px 0 2px; }}
      .reco2 {{ font-size:16px; font-weight:600; color:{INK}; margin:8px 0 4px; }}
      .strat {{ background:{SURFACE}; border:1px solid {HAIR}; border-radius:12px;
                padding:14px 16px; margin-bottom:10px; }}
      .strat.primary {{ border-color:{SERIES[0]}; background:{SURFACE2}; }}
      .strat.weak {{ opacity:.72; border-style:dashed; }}
      .star {{ font-size:11px; font-weight:700; color:{SERIES[0]};
               background:rgba(57,135,229,.15); padding:2px 8px; border-radius:6px; }}
      .sdot {{ display:inline-block; width:10px; height:10px; border-radius:50%;
               margin-right:6px; vertical-align:middle; }}
      .sdot.on {{ background:{STATUS['good']}; box-shadow:0 0 8px {STATUS['good']}; }}
      .sdot.off {{ background:{MUTED}; }}
      .entrow {{ display:flex; flex-wrap:wrap; gap:8px; margin:4px 0 8px; }}
      .ent {{ font-size:14px; padding:5px 11px; border-radius:8px; color:{INK}; }}
      .ent .etype {{ font-size:10px; color:{MUTED}; text-transform:uppercase;
                     letter-spacing:.05em; margin-left:5px; }}
      .relbox {{ background:{SURFACE}; border:1px solid {HAIR}; border-radius:10px;
                 padding:10px 14px; margin-bottom:8px; }}
      .rel {{ font-size:13.5px; margin:3px 0; }}
      .rel .rt {{ color:{INK}; font-weight:600; }}
      .rel .rarrow {{ color:{SERIES[2]}; font-family:ui-monospace,monospace; font-size:12px; }}
      .kglegend {{ display:flex; gap:20px; margin:6px 0 10px; font-size:13px; color:{INK2}; }}
      .kglegend .dot {{ display:inline-block; width:11px; height:11px; border-radius:50%;
                        margin-right:6px; vertical-align:middle; }}
      .kglegend .sq {{ display:inline-block; width:11px; height:11px; border-radius:2px;
                       margin-right:6px; vertical-align:middle; }}
    </style>
    """, unsafe_allow_html=True)


def kpi_row(items: list[tuple[str, str, str]]):
    cells = "".join(
        f'<div class="kpi"><div class="v">{v}</div><div class="l">{l}</div>'
        f'{f"<div class=s>{s}</div>" if s else ""}</div>'
        for (l, v, s) in items)
    st.markdown(f'<div class="kpi-row">{cells}</div>', unsafe_allow_html=True)


def badge_html(kind: str, lens: str | None = None) -> str:
    color, label = BADGE.get(kind, ("#898781", kind))
    lens_html = f'<span class="lens">{lens} lens</span>' if lens and lens != "none" else ""
    return f'<span class="badge" style="background:{color}">{label}</span>{lens_html}'


def section(title: str, subtitle: str = ""):
    st.markdown(f"### {title}")
    if subtitle:
        st.markdown(f'<div class="muted" style="margin-top:-8px;margin-bottom:10px">{subtitle}</div>',
                    unsafe_allow_html=True)


"""Step 8 (optional, one-off) — train domain word embeddings for the neural tier.

Trains FastText on the FULL unlabeled corpus (all ~12k records, normalized text),
NOT just the gold. Unsupervised: it reads raw text only, never labels, so it does
not leak the frozen test set. Run this ONCE before training Tier 2 with embeddings.

  python scripts/08_make_embeddings.py

Writes outputs/embeddings/domain_ft.model, which 05_train_eval.py picks up
automatically for the BiLSTM-CRF (and neural RE) if present.
"""
import _bootstrap  # noqa: F401

from src.data.corpus import load
from src.data.preannotate import preannotate
from src.models.embeddings import train_fasttext


def main():
    df, pool, norm_map, _ = load()
    # tokenise every record's (normalized) text the same way the models do
    texts = [t for t in df["text"].tolist() if t and t.strip()]
    sentences = [preannotate(t)["tokens"] for t in texts]
    sentences = [s for s in sentences if s]
    print(f"Training FastText on {len(sentences)} records "
          f"({sum(len(s) for s in sentences)} tokens)...")
    model = train_fasttext(sentences)
    print(f"vocab={len(model.wv)}  dim={model.wv.vector_size}")
    print("Saved -> outputs/embeddings/domain_ft.model")
    print("Tier 2 (05_train_eval.py --tiers 2) will now use these embeddings.")


if __name__ == "__main__":
    main()


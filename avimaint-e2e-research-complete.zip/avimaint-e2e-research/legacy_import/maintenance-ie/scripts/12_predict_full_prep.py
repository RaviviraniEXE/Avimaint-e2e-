"""Step 12 — prepare the FULL corpus for SpERT prediction (best-model KG pass).

Tokenizes every record of the full aviation corpus with the SAME tokenizer used
for the gold, and writes a SpERT-format input file (tokens only, empty labels)
plus an index that ties each row back to its record id and tokens. SpERT then
predicts entities and relations for the whole corpus, and step 13 builds the KG.

  python scripts/12_predict_full_prep.py                      # all records
  python scripts/12_predict_full_prep.py --unique             # dedup pool only

Writes:
  outputs/kg/full_corpus_spert.json   (SpERT input: [{tokens, entities:[], relations:[]}])
  outputs/kg/full_index.jsonl         (per row: {ident, tokens} in the same order)
"""
import _bootstrap  # noqa: F401
import argparse
import json
import os

from src.data.corpus import load
from src.data.preannotate import tokenize


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--unique", action="store_true", help="use the deduplicated unique pool")
    ap.add_argument("--min-tokens", type=int, default=1)
    args = ap.parse_args()
    os.makedirs("outputs/kg", exist_ok=True)

    df, pool, norm_map, stats = load()
    frame = pool if args.unique else df
    spert_in, index = [], []
    for _, row in frame.iterrows():
        text = (row.get("text") or "").strip()
        if not text:
            continue
        toks = [t for (t, s, e) in tokenize(text)]
        if len(toks) < args.min_tokens:
            continue
        spert_in.append({"tokens": toks, "entities": [], "relations": []})
        index.append({"ident": str(row.get("IDENT", len(index))), "tokens": toks})

    json.dump(spert_in, open("outputs/kg/full_corpus_spert.json", "w", encoding="utf-8"),
              ensure_ascii=False)
    with open("outputs/kg/full_index.jsonl", "w", encoding="utf-8") as f:
        for r in index:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"prepared {len(spert_in)} records -> outputs/kg/full_corpus_spert.json "
          f"({'unique pool' if args.unique else 'all records'})")
    print("next: run SpERT prediction on this file, then scripts/13_build_kg.py")


if __name__ == "__main__":
    main()

"""Step 13 — build the maintenance Knowledge Graph from extracted predictions.

Reads per-record extractions ({tokens, entities:[{start,end,type}],
relations:[{head,tail,type}]}) — either the SpERT predictions over the full
corpus (best model) or the gold corpus — canonicalizes entity mentions into
nodes, aggregates identical typed relations into weighted edges, builds a typed
directed graph, and exports it for analysis and for the planning dashboard.

  python scripts/13_build_kg.py --pred outputs/kg/predictions_full.jsonl --name aviation
  python scripts/13_build_kg.py --pred "outputs/gold/*.jsonl" --name aviation_gold   # gold KG

Outputs (under outputs/kg/<name>/):
  nodes.csv  edges.csv  <name>_kg.graphml  <name>_kg.json
  view_item_faults.csv  view_fault_actions.csv  view_item_parts.csv
  view_fault_contexts.csv  view_action_references.csv  summary.txt
"""
import _bootstrap  # noqa: F401
import argparse
import glob
import json
import os
import re
from collections import Counter, defaultdict

import networkx as nx

# Optional abbreviation map (plug in the normalization lexicon here to expand
# e.g. cyl -> cylinder). Left minimal by default.
ABBREV = {}


def canon(surface, etype):
    """Canonical label for a mention: lowercase, collapse space, trim, expand
    abbreviations, and singularize plural items so mentions merge into one node."""
    s = re.sub(r"\s+", " ", surface.lower()).strip(" .,;:-")
    s = ABBREV.get(s, s)
    if etype == "MAINT_ITEM" and len(s) > 4 and s.endswith("s") and not s.endswith("ss"):
        s = s[:-1]
    return s


def load_records(pattern):
    recs = []
    files = glob.glob(pattern) if any(c in pattern for c in "*?[") else [pattern]
    for f in files:
        if f.endswith(".jsonl"):
            for line in open(f, encoding="utf-8"):
                line = line.strip()
                if line:
                    recs.append(json.loads(line))
        else:
            recs.extend(json.load(open(f, encoding="utf-8")))
    return recs


def surface(rec, e):
    return " ".join(rec["tokens"][e["start"]:e["end"]])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred", required=True, help="predictions jsonl / json / glob")
    ap.add_argument("--name", default="aviation")
    ap.add_argument("--tokens", help="jsonl with {tokens} per row, in prediction order (if preds lack tokens)")
    ap.add_argument("--min-weight", type=int, default=1,
                    help="drop edges supported by fewer than this many records (planning views)")
    args = ap.parse_args()
    out = f"outputs/kg/{args.name}"
    os.makedirs(out, exist_ok=True)

    recs = load_records(args.pred)
    if args.tokens:                         # SpERT preds may omit tokens; supply by row order
        idx = [json.loads(l) for l in open(args.tokens, encoding="utf-8") if l.strip()]
        for i, r in enumerate(recs):
            if not r.get("tokens") and i < len(idx):
                r["tokens"] = idx[i]["tokens"]
                r.setdefault("ident", idx[i].get("ident", i))
    node_count = Counter()                     # (label,type) -> mention count
    edge_w = Counter()                         # (u_label,u_type, rel, v_label,v_type) -> weight
    edge_support = defaultdict(list)           # edge -> [record ids]
    records = []                               # per-record text + entities, for the solution finder
    sol_count = Counter()                      # (issue, action, item, kind) -> count  (grounded solutions)
    for ri, rec in enumerate(recs):
        ents = rec["entities"]
        rid = rec.get("ident", ri)
        cnodes = []
        for e in ents:
            lab = canon(surface(rec, e), e["type"])
            if not lab:
                cnodes.append(None); continue
            cnodes.append((lab, e["type"]))
            node_count[(lab, e["type"])] += 1
        by = defaultdict(list)
        for cn in cnodes:
            if cn:
                by[cn[1]].append(cn[0])
        def _u(xs):                            # unique, order-preserving
            return "; ".join(dict.fromkeys(xs))
        records.append({"ident": rid, "text": " ".join(rec.get("tokens", [])),
                        "items": _u(by["MAINT_ITEM"]),
                        "faults": _u(by["FAULT"] + by["ABN_PROC"]),
                        "actions": _u(by["ACTION"])})
        act_items = defaultdict(list)          # action entity idx -> [item labels it acts on/uses]
        act_issues = []                        # (action idx, issue label, kind) it addresses/investigates
        for r in rec.get("relations", []):
            h, t = r["head"], r["tail"]
            if h >= len(cnodes) or t >= len(cnodes) or cnodes[h] is None or cnodes[t] is None:
                continue
            key = (cnodes[h][0], cnodes[h][1], r["type"], cnodes[t][0], cnodes[t][1])
            edge_w[key] += 1
            edge_support[key].append(rid)
            # collect the pieces of a grounded solution: action --acts on--> item, action --fixes--> fault
            if r["type"] in ("ACTION_ON_ITEM", "ACTION_USES_ITEM") and cnodes[t][1] == "MAINT_ITEM":
                act_items[h].append(cnodes[t][0])
            elif r["type"] in ("ACTION_ADDRESSES_ISSUE", "ACTION_INVESTIGATES_ISSUE"):
                kind = "addresses" if r["type"] == "ACTION_ADDRESSES_ISSUE" else "investigates"
                act_issues.append((h, cnodes[t][0], kind))
        # pair each fault-fixing action with the item it was applied to IN THE SAME RECORD
        for a_idx, issue_lab, kind in act_issues:
            action_lab = cnodes[a_idx][0]
            items = list(dict.fromkeys(act_items.get(a_idx, [])))
            if items:
                for it in items:
                    sol_count[(issue_lab, action_lab, it, kind)] += 1
            else:
                sol_count[(issue_lab, action_lab, "", kind)] += 1

    # ---- build graph ----
    G = nx.MultiDiGraph(name=args.name)
    for (lab, typ), c in node_count.items():
        G.add_node(f"{typ}:{lab}", label=lab, type=typ, count=int(c))
    for (ul, ut, rel, vl, vt), w in edge_w.items():
        G.add_edge(f"{ut}:{ul}", f"{vt}:{vl}", key=rel, relation=rel, weight=int(w))

    # ---- exports: nodes / edges ----
    with open(f"{out}/nodes.csv", "w", encoding="utf-8") as f:
        f.write("node_id,label,type,mention_count\n")
        for (lab, typ), c in sorted(node_count.items(), key=lambda x: -x[1]):
            f.write(f'"{typ}:{lab}","{lab}",{typ},{c}\n')
    with open(f"{out}/edges.csv", "w", encoding="utf-8") as f:
        f.write("source,relation,target,weight\n")
        for (ul, ut, rel, vl, vt), w in sorted(edge_w.items(), key=lambda x: -x[1]):
            f.write(f'"{ut}:{ul}",{rel},"{vt}:{vl}",{w}\n')
    nx.write_graphml(G, f"{out}/{args.name}_kg.graphml")
    json.dump(nx.node_link_data(G), open(f"{out}/{args.name}_kg.json", "w"), ensure_ascii=False)

    # ---- per-record table (for the text-input solution finder) ----
    import csv
    with open(f"{out}/records.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["ident", "text", "items", "faults", "actions"])
        for r in records:
            if r["text"].strip():
                w.writerow([r["ident"], r["text"], r["items"], r["faults"], r["actions"]])

    # ---- grounded solutions view (fault -> action + the item it was applied to) ----
    # This is what powers full-sentence recommendations like "replace the intake gasket".
    with open(f"{out}/view_fault_solutions.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["issue", "action", "item", "kind", "count"])
        for (issue, action, item, kind), c in sorted(sol_count.items(), key=lambda x: -x[1]):
            w.writerow([issue, action, item, kind, c])

    # ---- planning views (the DSS logic) ----
    def dump_view(fname, header, rows):
        with open(f"{out}/{fname}", "w", encoding="utf-8") as f:
            f.write(header + "\n")
            for r in rows:
                f.write(",".join(f'"{x}"' if isinstance(x, str) else str(x) for x in r) + "\n")

    def edges_of(rel):
        return [((ul, ut), (vl, vt), w) for (ul, ut, r, vl, vt), w in edge_w.items()
                if r == rel and w >= args.min_weight]

    # item -> fault  (what fails)
    itf = sorted(edges_of("ISSUE_ON_ITEM"), key=lambda x: -x[2])
    dump_view("view_item_faults.csv", "item,issue,issue_type,count",
              [(v[0], u[0], u[1], w) for u, v, w in itf])   # ISSUE_ON_ITEM: issue -> item
    # fault -> action  (what fixes / investigates it) — the solution recommender
    fa = []
    for rel, kind in (("ACTION_ADDRESSES_ISSUE", "addresses"), ("ACTION_INVESTIGATES_ISSUE", "investigates")):
        for u, v, w in edges_of(rel):                        # ACTION -> ISSUE
            fa.append((v[0], u[0], kind, w))                 # issue, action, kind, count
    fa.sort(key=lambda x: -x[3])
    dump_view("view_fault_actions.csv", "issue,action,kind,count", fa)
    # item -> part
    dump_view("view_item_parts.csv", "whole,part,count",
              [(u[0], v[0], w) for u, v, w in sorted(edges_of("HAS_PART"), key=lambda x: -x[2])])
    # fault -> context
    dump_view("view_fault_contexts.csv", "issue,context,count",
              [(u[0], v[0], w) for u, v, w in sorted(edges_of("OCCURS_UNDER_CONTEXT"), key=lambda x: -x[2])])
    # action -> reference
    dump_view("view_action_references.csv", "action,reference,count",
              [(u[0], v[0], w) for u, v, w in sorted(edges_of("ACTION_FOLLOWS_REFERENCE"), key=lambda x: -x[2])])

    # ---- summary ----
    with open(f"{out}/summary.txt", "w", encoding="utf-8") as f:
        f.write(f"Knowledge Graph: {args.name}\n")
        f.write(f"records={len(recs)}  nodes={G.number_of_nodes()}  edges(aggregated)={G.number_of_edges()}\n")
        f.write(f"total entity mentions={sum(node_count.values())}  total relation instances={sum(edge_w.values())}\n\n")
        f.write("nodes by type:\n")
        bytype = Counter(t for (_, t) in node_count)
        for t, c in bytype.most_common():
            f.write(f"  {t}: {c} distinct\n")
        f.write("\nedges by relation:\n")
        byrel = Counter()
        for (ul, ut, rel, vl, vt), w in edge_w.items():
            byrel[rel] += w
        for r, c in byrel.most_common():
            f.write(f"  {r}: {c} instances\n")
        f.write("\ntop 10 items by mentions:\n")
        top_items = [(lab, c) for (lab, typ), c in sorted(node_count.items(), key=lambda x: -x[1]) if typ == "MAINT_ITEM"][:10]
        for lab, c in top_items:
            f.write(f"  {lab}: {c}\n")
    print(f"KG '{args.name}': {G.number_of_nodes()} nodes, {G.number_of_edges()} aggregated edges "
          f"from {len(recs)} records -> {out}/")
    print(f"  planning views + graphml + json written to {out}/")


if __name__ == "__main__":
    main()

@echo off
setlocal
pushd "%~dp0\..\..\legacy_import\maintenance-ie"
call conda run -n avimaint-ie-classical python scripts\05_train_eval.py --tiers 1 --tune --run-id core_tier1 --gold-glob "outputs/gold_core/*.jsonl" --schema-path config/schema_core.yaml --report-name ie_results_core
set RESULT=%ERRORLEVEL%
popd
if not "%RESULT%"=="0" pause
exit /b %RESULT%


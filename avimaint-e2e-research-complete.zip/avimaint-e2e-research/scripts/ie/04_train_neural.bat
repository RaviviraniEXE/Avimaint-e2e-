@echo off
setlocal
pushd "%~dp0\..\..\legacy_import\maintenance-ie"
if not exist outputs\splits.json (
  echo ERROR: final frozen split missing. Run 02_freeze_split.bat after importing random gold.
  popd
  exit /b 3
)
call conda run -n avimaint-ie-neural python scripts\08_make_embeddings.py
if errorlevel 1 goto :failed
call conda run -n avimaint-ie-neural python scripts\05_train_eval.py --tiers 2 3 --run-id aviation_neural
if errorlevel 1 goto :failed
call conda run -n avimaint-ie-neural python scripts\09_report.py --tiers 2 3 --bootstrap 1000 --save-models --run-id aviation_neural_final
set RESULT=%ERRORLEVEL%
popd
exit /b %RESULT%
:failed
set RESULT=%ERRORLEVEL%
popd
exit /b %RESULT%

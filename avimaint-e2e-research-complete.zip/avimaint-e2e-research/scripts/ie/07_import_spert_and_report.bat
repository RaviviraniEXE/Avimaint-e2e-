@echo off
setlocal
pushd "%~dp0\..\..\legacy_import\maintenance-ie"
call conda run -n avimaint-ie-neural python scripts\06b_import_spert_preds.py outputs\spert\predictions_test.json
if errorlevel 1 goto :failed
call conda run -n avimaint-ie-neural python scripts\09_report.py --tiers 1 2 3 --spert outputs\reports\spert_test.json --bootstrap 1000 --run-id aviation_all_tiers
if errorlevel 1 goto :failed
call conda run -n avimaint-ie-neural python scripts\10_significance.py --tiers 1 2 3 --seeds 3 --bootstrap 1000
set RESULT=%ERRORLEVEL%
popd
exit /b %RESULT%
:failed
set RESULT=%ERRORLEVEL%
popd
exit /b %RESULT%

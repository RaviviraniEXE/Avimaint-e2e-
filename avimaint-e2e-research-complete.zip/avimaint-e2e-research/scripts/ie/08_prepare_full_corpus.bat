@echo off
setlocal
pushd "%~dp0\..\..\legacy_import\maintenance-ie"
call conda run -n avimaint-ie-classical python scripts\12_predict_full_prep.py
set RESULT=%ERRORLEVEL%
popd
exit /b %RESULT%

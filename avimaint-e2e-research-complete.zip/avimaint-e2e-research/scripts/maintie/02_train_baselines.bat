@echo off
setlocal
pushd "%~dp0\..\..\legacy_import\maintie-bench"
call conda run -n avimaint-ie-classical python scripts\05_train_eval.py --tiers 1 --tune --run-id maintie_tier1
if errorlevel 1 goto :failed
call conda run -n avimaint-ie-neural python scripts\08_make_embeddings.py
if errorlevel 1 goto :failed
call conda run -n avimaint-ie-neural python scripts\05_train_eval.py --tiers 2 3 --run-id maintie_neural
set RESULT=%ERRORLEVEL%
popd
exit /b %RESULT%
:failed
set RESULT=%ERRORLEVEL%
popd
exit /b %RESULT%

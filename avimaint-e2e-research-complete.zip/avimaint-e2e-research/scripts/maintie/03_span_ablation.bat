@echo off
setlocal
pushd "%~dp0\..\..\legacy_import\maintie-bench"
call conda run -n avimaint-ie-neural python scripts\11_span_ner.py --encoders bilstm transformer --max-span 10 --epochs 30
set RESULT=%ERRORLEVEL%
popd
exit /b %RESULT%

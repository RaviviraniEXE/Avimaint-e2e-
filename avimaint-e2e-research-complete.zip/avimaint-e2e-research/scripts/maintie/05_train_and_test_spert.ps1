$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$Bench = Join-Path $Root "legacy_import\maintie-bench"
$SpERT = Join-Path $Root "external\spert"
$Provenance = Join-Path $SpERT "UPSTREAM_PROVENANCE.json"
if (-not (Test-Path (Join-Path $SpERT ".git")) -or -not (Test-Path $Provenance)) {
    throw "Official SpERT is not installed. Run scripts\setup\clone_official_spert.bat first."
}
$Export = Join-Path $Bench "outputs\spert"
& conda run -n avimaint-spert python (Join-Path $SpERT "spert.py") train --config (Join-Path $Export "avimaint_spert.conf")
$Model = Get-ChildItem (Join-Path $Export "save") -Recurse -Directory -Filter final_model | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $Model) { throw "MaintIE SpERT final_model was not created." }
& conda run -n avimaint-spert python (Join-Path $SpERT "spert.py") predict `
  --dataset_path (Join-Path $Export "test.json") --types_path (Join-Path $Export "avimaint_types.json") `
  --model_path $Model.FullName --tokenizer_path $Model.FullName `
  --predictions_path (Join-Path $Export "predictions_test.json") --model_type spert `
  --eval_batch_size 1 --max_span_size 10 --seed 42
Write-Host "MaintIE frozen-test predictions: $Export\predictions_test.json"

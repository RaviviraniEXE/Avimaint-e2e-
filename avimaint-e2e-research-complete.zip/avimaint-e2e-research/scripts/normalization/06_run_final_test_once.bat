@echo off
setlocal EnableDelayedExpansion
if /I not "%~1"=="CONFIRM_TEST" (
  echo Final test is locked. First select the final configuration using validation only.
  echo Run: scripts\normalization\06_run_final_test_once.bat CONFIRM_TEST
  exit /b 2
)
pushd "%~dp0..\.."
for %%S in (raw rules byt5 rules_then_byt5) do (
  echo Running final test prediction and evaluation for %%S
  conda run -n avimaint-normalization python -m avimaint.normalization predict --config configs/normalization/byt5_gold.yaml --split test --system %%S
  if errorlevel 1 goto :failed
  conda run -n avimaint-normalization python -m avimaint.normalization evaluate --config configs/normalization/byt5_gold.yaml --split test --system %%S
  if errorlevel 1 goto :failed
)
popd
exit /b 0

:failed
set RESULT=%ERRORLEVEL%
popd
exit /b %RESULT%

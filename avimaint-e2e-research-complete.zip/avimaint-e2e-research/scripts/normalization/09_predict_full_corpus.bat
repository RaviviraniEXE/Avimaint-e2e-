@echo off
setlocal EnableDelayedExpansion
pushd "%~dp0\..\.."
for %%S in (raw rules byt5 rules_then_byt5) do (
  echo Full-corpus inference for %%S
  call conda run -n avimaint-normalization python -m avimaint.normalization predict-corpus --config configs/normalization/byt5_gold.yaml --system %%S
  if errorlevel 1 goto :failed
)
popd
exit /b 0
:failed
set RESULT=%ERRORLEVEL%
popd
exit /b %RESULT%

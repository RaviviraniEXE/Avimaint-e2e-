# Numbered normalization launchers

These `.bat` files are the familiar Windows/Anaconda Prompt entry points. The
real implementation is under `src/avimaint/normalization/`; the launchers call
that code with the versioned YAML configuration.

| Step | Launcher | Main implementation |
|---:|---|---|
| 1 | `01_audit_reference.bat` | `audit.py` |
| 2 | `02_prepare_approved_pairs.bat` | `audit.py` |
| 3 | `03_create_cluster_safe_split.bat` | `splitting.py` |
| 4 | `04_train_byt5_gold.bat` | `training.py` |
| 5 | `05_run_validation_comparison.bat` | `prediction.py`, `evaluation.py` |
| 5c | `05c_run_expert_sensitivity.bat` | separate expert-completion sensitivity population |
| 6 | `06_run_final_test_once.bat` | locked final evaluation |
| 7 | `07_make_silver_data.bat` | `silver.py`, `rules.py` |
| 8 | `08_train_silver_then_gold.bat` | `training.py` |
| 9 | `09_predict_full_corpus.bat` | field-preserving full-corpus inference |
| 10 | `10_compare_downstream_ie.bat` | audited span projection + frozen IE ablation |

The old normalization scripts are not copied into the new implementation. Put
old source under `legacy_import/normalization/` only when it is needed for an
auditable baseline comparison.

`05c` never participates in model selection. It measures agreement on 1,045
expert completions whose missing content may not be recoverable from the raw
fixed-width record, so it must be reported separately from primary lexical
normalization.

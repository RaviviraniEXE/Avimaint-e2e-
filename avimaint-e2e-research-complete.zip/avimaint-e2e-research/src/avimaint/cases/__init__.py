"""Structured historical-case construction."""


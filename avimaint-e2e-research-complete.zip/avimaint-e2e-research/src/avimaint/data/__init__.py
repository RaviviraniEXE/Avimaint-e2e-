"""Dataset adapters and validation."""


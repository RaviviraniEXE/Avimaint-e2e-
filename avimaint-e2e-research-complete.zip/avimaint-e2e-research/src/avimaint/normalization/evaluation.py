"""Strict held-out evaluation with ID checks and bootstrap intervals."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from avimaint.normalization.io import read_table, require_columns, write_json
from avimaint.normalization.metrics import score_corpus


def _bootstrap(frame: Any, samples: int = 1000, seed: int = 42) -> dict[str, list[float]]:
    generator = np.random.default_rng(seed)
    collected: dict[str, list[float]] = {}
    for _ in range(samples):
        indices = generator.integers(0, len(frame), size=len(frame))
        sampled = frame.iloc[indices]
        scores = score_corpus(
            sampled["raw_text"], sampled["prediction_text"], sampled["reference_text"]
        )
        for key, value in scores.items():
            collected.setdefault(key, []).append(float(value))
    return {
        key: [float(np.quantile(values, 0.025)), float(np.quantile(values, 0.975))]
        for key, values in collected.items()
    }


def evaluate(config: dict[str, Any], split: str, system: str) -> Path:
    run = config["run"]
    gold_path = run.get("input_path") or run.get("gold_input_path")
    gold = read_table(gold_path)
    require_columns(gold, ["example_id", "split"], "frozen split")
    expected = set(gold.loc[gold["split"] == split, "example_id"].astype(str))
    prediction_path = Path(run["prediction_dir"]) / f"{split}_{system}.csv"
    predictions = read_table(prediction_path)
    require_columns(
        predictions,
        ["example_id", "raw_text", "prediction_text", "reference_text"],
        "predictions",
    )
    observed = set(predictions["example_id"].astype(str))
    if observed != expected:
        missing = sorted(expected - observed)[:5]
        unexpected = sorted(observed - expected)[:5]
        raise ValueError(f"Prediction ID mismatch; missing={missing}, unexpected={unexpected}")
    if predictions["example_id"].duplicated().any():
        raise ValueError("Predictions contain duplicate example IDs")
    scores = score_corpus(
        predictions["raw_text"],
        predictions["prediction_text"],
        predictions["reference_text"],
    )
    payload = {
        "run_id": run["id"],
        "split": split,
        "system": system,
        "records": len(predictions),
        "metrics": scores,
        "bootstrap_95_ci": _bootstrap(predictions, seed=int(run["seed"])),
        "prediction_path": str(prediction_path),
    }
    output = Path(run["prediction_dir"]) / f"{split}_{system}_metrics.json"
    write_json(payload, output)
    return output

"""Generate raw, rule, ByT5 and selective-ByT5 predictions."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from avimaint.normalization.io import read_table, require_columns, write_table
from avimaint.normalization.mfr import apply_replacements, learn_replacements
from avimaint.normalization.protected import validate_protected
from avimaint.normalization.rules import load_replacements, normalize_rules


def _model_dir(config: dict[str, Any]) -> Path:
    root = Path(config["run"]["output_dir"])
    manifest = root / "run_manifest.json"
    if manifest.exists():
        import json

        return Path(json.loads(manifest.read_text(encoding="utf-8"))["final_model_dir"])
    return root


def predict(config: dict[str, Any], split: str, system: str = "selective_byt5") -> Path:
    run = config["run"]
    input_path = run.get("input_path") or run.get("gold_input_path")
    frame = read_table(input_path)
    require_columns(frame, ["example_id", "raw_text", "target_text", "split"], "split data")
    frame = frame[frame["split"] == split].copy()
    if frame.empty:
        raise ValueError(f"No rows found for split={split}")
    replacements = load_replacements("data/dictionaries/abbreviations.yaml")

    if system == "raw":
        candidates = frame["raw_text"].astype(str).tolist()
    elif system == "most_frequent_replacement":
        training_rows = read_table(input_path)
        training_rows = training_rows[training_rows["split"] == "train"]
        mapping = learn_replacements(training_rows)
        candidates = [apply_replacements(text, mapping) for text in frame["raw_text"]]
    elif system == "rules":
        candidates = [normalize_rules(text, replacements) for text in frame["raw_text"]]
    elif system in {"byt5", "selective_byt5", "rules_then_byt5"}:
        import torch
        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

        model_dir = _model_dir(config)
        tokenizer = AutoTokenizer.from_pretrained(model_dir)
        model = AutoModelForSeq2SeqLM.from_pretrained(model_dir)
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model.to(device)
        model.eval()
        candidates = []
        batch_size = int(config["training"]["per_device_eval_batch_size"])
        if system == "rules_then_byt5":
            inputs = [
                f"normalize {field}: {normalize_rules(text, replacements)}"
                for field, text in zip(frame["field"], frame["raw_text"].astype(str), strict=False)
            ]
        else:
            inputs = frame["input_text"].astype(str).tolist()
        for start in range(0, len(inputs), batch_size):
            batch = tokenizer(
                inputs[start : start + batch_size],
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=int(config["model"]["max_source_length"]),
            ).to(device)
            with torch.inference_mode():
                generated = model.generate(
                    **batch,
                    max_length=int(config["model"]["max_target_length"]),
                    num_beams=int(config["model"].get("num_beams", 1)),
                )
            candidates.extend(tokenizer.batch_decode(generated, skip_special_tokens=True))
    else:
        raise ValueError(f"Unknown prediction system: {system}")

    selected: list[str] = []
    accepted: list[bool] = []
    fallback: list[str] = []
    for source, candidate in zip(frame["raw_text"].astype(str), candidates, strict=False):
        protection = validate_protected(source, candidate)
        if system == "selective_byt5" and not protection.accepted:
            rules = normalize_rules(source, replacements)
            if validate_protected(source, rules).accepted:
                selected.append(rules)
                fallback.append("rules")
            else:
                selected.append(source)
                fallback.append("raw")
            accepted.append(False)
        else:
            selected.append(candidate)
            fallback.append("none")
            accepted.append(protection.accepted)

    output = pd.DataFrame(
        {
            "example_id": frame["example_id"].astype(str),
            "record_id": frame["record_id"].astype(str),
            "split": split,
            "system": system,
            "raw_text": frame["raw_text"].astype(str),
            "reference_text": frame["target_text"].astype(str),
            "candidate_text": candidates,
            "prediction_text": selected,
            "protected_tokens_preserved": accepted,
            "fallback": fallback,
        }
    )
    path = Path(run["prediction_dir"]) / f"{split}_{system}.csv"
    write_table(output, path)
    return path


def predict_corpus(config: dict[str, Any], system: str) -> Path:
    """Apply a frozen normalizer to every record while preserving field boundaries."""
    from avimaint.configuration import load_yaml

    data_config = load_yaml("configs/normalization/data.yaml")
    dataset = data_config["dataset"]
    frame = read_table(dataset["raw_path"])
    require_columns(
        frame,
        [dataset["raw_id_column"], dataset["raw_problem_column"], dataset["raw_action_column"]],
        "full aviation corpus",
    )
    separator = data_config["pairing"].get("combined_separator", " ")
    source_problem = frame[dataset["raw_problem_column"]].fillna("").astype(str).str.strip()
    source_action = frame[dataset["raw_action_column"]].fillna("").astype(str).str.strip()
    source = (source_problem + separator + source_action).str.strip()
    replacements = load_replacements("data/dictionaries/abbreviations.yaml")
    if system == "raw":
        problem_predictions, action_predictions = source_problem.tolist(), source_action.tolist()
    elif system == "rules":
        problem_predictions = [normalize_rules(text, replacements) for text in source_problem]
        action_predictions = [normalize_rules(text, replacements) for text in source_action]
    elif system in {"byt5", "rules_then_byt5"}:
        import torch
        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

        model_dir = _model_dir(config)
        tokenizer = AutoTokenizer.from_pretrained(model_dir)
        model = AutoModelForSeq2SeqLM.from_pretrained(model_dir)
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model.to(device)
        model.eval()

        def generate(values: list[str], field: str) -> list[str]:
            if system == "rules_then_byt5":
                values = [normalize_rules(text, replacements) for text in values]
            inputs = [f"normalize {field}: {text}" for text in values]
            candidates: list[str] = []
            batch_size = int(config["training"]["per_device_eval_batch_size"])
            for start in range(0, len(inputs), batch_size):
                batch = tokenizer(
                    inputs[start : start + batch_size],
                    return_tensors="pt",
                    padding=True,
                    truncation=True,
                    max_length=int(config["model"]["max_source_length"]),
                ).to(device)
                with torch.inference_mode():
                    generated = model.generate(
                        **batch,
                        max_length=int(config["model"]["max_target_length"]),
                        num_beams=int(config["model"].get("num_beams", 1)),
                    )
                candidates.extend(tokenizer.batch_decode(generated, skip_special_tokens=True))
            return candidates

        # Amin supplies one combined cleaned target, so the trained task prefix
        # is "combined" even when field-preserving inference is applied to each
        # source field independently for downstream use.
        problem_predictions = generate(source_problem.tolist(), "combined")
        action_predictions = generate(source_action.tolist(), "combined")
    else:
        raise ValueError(
            "Full-corpus inference supports primary systems: raw, rules, byt5, rules_then_byt5"
        )
    candidates = [
        f"{problem}{separator}{action}".strip()
        for problem, action in zip(problem_predictions, action_predictions, strict=False)
    ]
    preserved = [
        validate_protected(src, pred).accepted
        for src, pred in zip(source, candidates, strict=False)
    ]
    output = pd.DataFrame(
        {
            "record_id": frame[dataset["raw_id_column"]].astype(str),
            "system": system,
            "raw_text": source,
            "prediction_text": candidates,
            "problem_raw": source_problem,
            "action_raw": source_action,
            "problem_normalized": problem_predictions,
            "action_normalized": action_predictions,
            "protected_tokens_preserved": preserved,
        }
    )
    path = Path("outputs/normalization/full_corpus") / f"{system}.csv"
    write_table(output, path)
    return path

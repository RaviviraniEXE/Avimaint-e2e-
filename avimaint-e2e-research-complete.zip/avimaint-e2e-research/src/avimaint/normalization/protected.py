"""Protected-token extraction and output validation."""

from __future__ import annotations

import re
from dataclasses import dataclass

DEFAULT_PATTERNS = [
    r"\b[A-Z]{1,5}[-/]?\d[A-Z0-9./-]*\b",
    r"\b\d+(?:\.\d+)?\s?(?:V|A|PSI|PSIG|IN|MM|CM|NM|LB|LBS|HR|HRS|MIN|SEC|DEG|°C|°F)\b",
    r"\b(?:LEFT|RIGHT|LH|RH|NO|NOT|NEVER)\b",
]


@dataclass(frozen=True)
class ProtectionResult:
    accepted: bool
    missing_tokens: tuple[str, ...]


def extract_protected(text: str, patterns: list[str] | None = None) -> list[str]:
    found: list[str] = []
    for pattern in patterns or DEFAULT_PATTERNS:
        found.extend(match.group(0) for match in re.finditer(pattern, text, flags=re.IGNORECASE))
    return found


def validate_protected(
    source: str, candidate: str, patterns: list[str] | None = None
) -> ProtectionResult:
    expected = extract_protected(source, patterns)
    candidate_lower = candidate.lower()
    missing = tuple(token for token in expected if token.lower() not in candidate_lower)
    return ProtectionResult(accepted=not missing, missing_tokens=missing)

"""Deterministic stress-test transformations."""


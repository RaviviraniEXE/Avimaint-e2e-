"""Schema registry and mapping."""


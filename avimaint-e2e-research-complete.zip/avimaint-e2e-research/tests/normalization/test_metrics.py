from avimaint.normalization.metrics import score_corpus


def test_perfect_prediction() -> None:
    scores = score_corpus(["repl pump"], ["replaced pump"], ["replaced pump"])
    assert scores["wer"] == 0.0
    assert scores["exact_match"] == 1.0
    assert scores["change_f1"] == 1.0


def test_protected_identifier_failure() -> None:
    scores = score_corpus(
        ["removed PUMP-12"],
        ["removed pump"],
        ["removed PUMP-12"],
    )
    assert scores["protected_token_accuracy"] == 0.0

"""Deterministic structured-sentence composition for recommendations.

Turns a grounded strategy (action family + target component + fault + whether a
verification step is on record) into a clean imperative recommendation sentence.
It changes tense/joins concepts only — it never invents an action, part, or
check that is not present in the supporting evidence.
"""
from __future__ import annotations

import re

# Family -> imperative verb phrase (target slot = {t})
_FAMILY_VERB = {
    "Replace": "Replace {t}",
    "Repair": "Repair {t}",
    "Adjust": "Adjust and re-secure {t}",
    "Service": "Service {t}",
    "Inspect": "Inspect {t}",
    "Diagnose": "Run up and diagnose {t}",
    "Calibrate": "Calibrate {t}",
}

# Plain-language meaning of each strategy (so alternatives read meaningfully)
_FAMILY_MEANING = {
    "Replace": "Renew the part with a new one.",
    "Repair": "Fix the existing part in place (weld, reseat, patch, re-swage).",
    "Adjust": "Re-set, re-torque or re-secure it — no new part.",
    "Service": "Clean, reseal, or service the part.",
    "Inspect": "Inspect to assess condition before committing to a repair.",
    "Diagnose": "Run or test first to find and confirm the cause.",
    "Calibrate": "Calibrate or re-time to specification.",
    "Other": "Recorded action (family not classified).",
}

_VERIFY_RE = re.compile(r"leak\s*(ck|check)|ops\s*(ck|check)|ground\s*(ck|check)|"
                        r"run\s*up|checked good|check good|ops good|functional check", re.I)
_FAULT_ADJ = {
    "leak": "leaking", "crack": "cracked", "wear": "worn", "loose": "loose",
    "corrosion": "corroded", "burnt": "burnt", "broken": "broken",
    "chafing": "chafed", "vibration": "vibrating",
}
# noun phrase for "diagnose ... to isolate the {noun}"
_FAULT_NOUN = {
    "leak": "leak", "crack": "crack", "wear": "wear", "loose": "looseness",
    "corrosion": "corrosion", "vibration": "vibration", "noise": "noise",
    "low compression": "low compression", "rough running": "rough running",
    "power loss": "power loss", "will not start": "no-start",
    "quit / shutdown": "shutdown", "smoke": "smoke",
}


def build_target(components: list[str], locations: list[str],
                 fallback: str = "the affected component") -> str:
    comp = components[0] if components else ""
    loc = " ".join(locations[:1]) if locations else ""
    if comp and loc:
        return f"the {loc} {comp}".replace("  ", " ")
    if comp:
        return f"the {comp}"
    if loc:
        return f"the {loc} component"
    return fallback


def with_fault(target: str, fault: str | None) -> str:
    """Insert a fault adjective: 'the intake gasket' -> 'the leaking intake gasket'."""
    if not fault:
        return target
    adj = _FAULT_ADJ.get(fault)
    if not adj or adj in target:
        return target
    m = re.match(r"^(the\s+)(.*)$", target)
    if m:
        return f"{m.group(1)}{adj} {m.group(2)}"
    return f"{adj} {target}"


def compose_sentence(family: str, target: str, fault: str | None = None,
                     has_verification: bool = False) -> str:
    verb = _FAMILY_VERB.get(family, "Address {t}")
    tgt = with_fault(target, fault) if family in ("Replace", "Repair", "Service") else target
    core = verb.format(t=tgt)
    if family == "Diagnose":
        core = f"Run up and diagnose {target}"
        noun = _FAULT_NOUN.get(fault or "")
        if noun:
            core += f" to isolate the {noun}"
    elif family == "Inspect":
        noun = _FAULT_NOUN.get(fault or "")
        core = f"Inspect {target}" + (f" for {noun}" if noun else "")
    sentence = core.strip()
    if has_verification and family in ("Replace", "Repair", "Adjust", "Service"):
        check = "leak-check" if fault == "leak" else "operationally check"
        sentence += f", then {check} to confirm the fault is cleared"
    return sentence.rstrip(".") + "."


def family_meaning(family: str) -> str:
    return _FAMILY_MEANING.get(family, _FAMILY_MEANING["Other"])


def cases_have_verification(action_texts: list[str]) -> bool:
    return any(_VERIFY_RE.search(t or "") for t in action_texts)

